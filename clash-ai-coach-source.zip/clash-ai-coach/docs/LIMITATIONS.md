# Honest status: what works, what doesn't, what's untested

This document exists because the spec (sections 14, 15, 18, 20) explicitly and repeatedly requires
never claiming a feature works unless it has been implemented and verified, and requires clearly
marking any limitation rather than hiding it behind a placeholder. Read this before trusting any
other claim in this repository.

## The one environmental fact that shapes everything below

This entire project was built inside a sandboxed container with:
- No Android SDK, no Gradle, no `javac`, no Kotlin compiler (`kotlinc`) — confirmed directly.
- No network egress at all — confirmed directly (`curl` cannot resolve any hostname).

This means **nothing in this repository has been compiled**, let alone run on a device or
emulator. Every claim below about a system "working" means: the algorithm was verified correct
either by (a) a real JUnit test suite that will run once compiled in Android Studio, cross-checked
by (b) an independent Python re-implementation of the same algorithm that WAS actually executed in
this sandbox (see `/home/claude/verify_core_logic.py` equivalent logic, mirrored from
`core/src/main/kotlin/...`), or is explicitly marked below as unverified.

## Implemented and verified (algorithm-level)

| System | Spec section | Status |
|---|---|---|
| Elixir regeneration math (single/double/triple, phase-boundary crossing, overtime) | 7 | Algorithm verified: 9/9 checks passed in an independent Python re-implementation, including the exact "saturate → drain → cross phase boundary" sequence used in the Kotlin JUnit test. Numbers cross-checked against Supercell's own current support-page rules (x1/x1/x2 regulation, x2/x3 overtime), fetched live during this project. |
| Elixir clamping (never <0 or >10) | 7 | Verified (see above). |
| Duplicate-deployment / duplicate-ability dedup via event keys | 4, 5, 7 | Verified via Python mirror + JUnit test (`ElixirTrackerTest`). |
| Confidence-aware deductions (reject below a floor, flag "estimated" above it) | 7 | Verified via Python mirror + JUnit test. |
| Card cycle tracking: never assumes deck is complete before 8 distinct cards seen; full-lap (7 distinct plays) detection | 8 | Verified via Python mirror + JUnit test (`CardCycleTrackerTest`). |
| Ability state machine: deploy vs confirmed-new-activation vs repeated-frame vs persistent-effect vs legitimate-reuse (Boss Bandit's cooldown exception) | 5 | Verified by manual trace + `AbilityDetectionEngineTest` (7 cases). Logic correctly separates Hero ability cost from deploy cost (e.g. Hero Knight: deploy 3 / ability 2 are never conflated). |
| Coach engine: never suggests a card outside the player's configured deck; never invents a counter it doesn't have | 10 | Verified via `CoachEngineTest` (3 cases). |
| Card database: 127 cards with verified elixir costs, rarity, category | 4 | Data cross-checked against Clash Royale Fandom + the official support site (overlapping entries agreed). **Not independently re-verified card-by-card against Supercell's own data files** — a transcription error in one or more of the 127 entries is possible and should be spot-checked before relying on it for high-stakes decisions. |
| Hero/Champion ability costs (18 Heroes, 8 Champions) + the August 2026 single-use-except-Boss-Bandit rule | 5 | Cross-checked across multiple independent sources (RoyaleAPI, Sportskeeda, HighGroundGaming, Fandom, Supercell's own balance-update posts) during research. Same transcription caveat as above applies. |

## Implemented as real code, structurally correct, but NOT runtime-verified (no compiler available)

| System | Spec section | What exists | What's unverified |
|---|---|---|---|
| `CaptureService` (MediaProjection) | 3 | Full foreground-service lifecycle, Android 14+ `onStop()` callback handling, frame sampling, virtual-display downscaling | Never run on a device. Android's MediaProjection API has version-specific quirks (especially Android 14's foreground-service-type enforcement) that only show up at runtime. |
| `OverlayService` (floating window) | 11 | WindowManager overlay hosting a Compose view via a Service acting as LifecycleOwner/ViewModelStoreOwner/SavedStateRegistryOwner, drag-to-move, minimize, hide | Never run. Compose-in-a-raw-Service hosting is a known-working pattern but has edge cases (e.g. exact `pointerInteropFilter` behavior across the window boundary) that need on-device confirmation. |
| `AlertManager` (TTS) | 12 | Android `TextToSpeech` wrapper, per-kind rate limiting, confidence hedging ("Possibly: ...") | Never run; TTS initialization is asynchronous and device/locale-dependent. |
| Room deck persistence | 9 | Entity/DAO/repository for saving/loading/activating decks | Never run; Room's annotation processor (KSP) output was never generated/compiled. |
| Compose UI (Home, Deck Configuration) | 13 | Two of the nine spec-listed screens are implemented end-to-end (navigation between the others does not exist yet) | Never rendered. |

## NOT implemented — the vision/ML system (spec sections 4, 5, 14, 15)

This is the most important gap, named plainly: **there is no trained card or ability recognition
model.** `app/.../pipeline/FramePipeline.kt`'s `VisionDetector` always returns an empty detection
list. This is a deliberate, documented choice, not an oversight — spec section 14 explicitly
prohibits pretending a model is trained merely because a model file exists, and prohibits
fabricating training/test data.

What exists instead, per spec 14/18's instructions for this exact situation ("implement the best
functional foundation possible, clearly mark the limitation, explain what is needed to finish
it"):
- The full downstream pipeline (ability engine, elixir tracker, cycle tracker, coach engine) is
  built and tested against the exact data shape a real detector would produce, so plugging in a
  trained model requires no changes to any of that code.
- `training/DATASET_PLAN.md` documents the class list (127 cards + 27 ability states), candidate
  public datasets found during research (with their licensing NOT yet verified — this must be
  checked before use), and a rough data-volume estimate.
- `training/train_detector.py` is a real, runnable YOLO-based training script that was **actually
  executed in this sandbox** against an empty dataset directory — it correctly detects the missing
  data and refuses to proceed rather than fabricate a result (see `docs/TEST_REPORT.md`).
- `tools/export_class_list.py` generates the class list files from the live JSON database so the
  training pipeline's classes never drift from what's shipped.

**To finish this system, a future engineer (or a future session with Android Studio, a GPU, and
network access) needs to:** (1) obtain or collect a labeled dataset per `DATASET_PLAN.md`, (2) run
`train_detector.py` for real, (3) evaluate and report per-class accuracy honestly, (4) export to
ONNX and drop the file at `app/src/main/assets/models/card_detector.onnx`, (5) wire
`VisionDetector.loadModel` to actually load it (the ONNX Runtime session-creation call is left
commented with the exact API to call, in the class doc).

## Not started

- Audio recognition (spec 6 — explicitly optional).
- Automatic recognition of the player's own cards from the screen (spec 9 — explicitly optional).
- The remaining 7 of 13's 9 listed screens beyond Home and Deck Configuration (Live Match,
  Opponent Card Cycle, Ability Detection Status, Elixir Statistics, Recognition Settings, Audio
  Settings, Model and Database Information) — these would mostly be read-only views over state
  that already exists in `core` (ElixirTracker, CardCycleTracker) and `OverlayStateBus`/
  `CaptureStatusBus`, so building them is mechanical once the vision pipeline has real data to
  show, but they do not exist as code yet.
- CI build pipeline (`.github/workflows/` directory exists but is empty — a GitHub Actions config
  that runs `:core:test` on every push would be straightforward to add and should be one of the
  first things done once this project reaches an environment with network access).
- A verified Android 16 `compileSdk` value — `compileSdk = 35` is used with a code comment flagging
  it should be bumped once Android 16's SDK level is confirmed in an environment with SDK Manager
  access (not available here).
