# Test report

**Every number on this page was actually produced by running something in this project's build
environment.** Nothing here is an estimate or a claim of untested behavior. Per spec section 15,
this report also states plainly what could NOT be tested and why.

## 1. Unit tests written (JUnit 5, in `core/src/test/kotlin`)

27 test cases across 4 files, covering exactly the spec-15-mandated areas that apply to `core`:

| File | Cases | Covers |
|---|---|---|
| `ElixirTrackerTest.kt` | 8 | Elixir calculations, phase transitions, deployment/ability deductions, duplicate-event prevention, confidence handling |
| `CardCycleTrackerTest.kt` | 4 | Card cycle logic, incomplete-deck handling |
| `AbilityDetectionEngineTest.kt` | 7 | Ability activation detection, deploy-vs-ability-vs-persistent-vs-repeat-vs-reuse distinction, confidence handling |
| `CoachEngineTest.kt` | 3 | Deck configuration constraint (never recommend an unowned card), confidence handling |

**These have NOT been executed by a JVM** — this sandbox has no `javac`/Kotlin compiler (verified:
`javac` is absent from the JDK install; no Kotlin compiler is installed; no network access exists
to fetch either). They will run via `./gradlew :core:test` the first time this project is opened in
an environment with a working toolchain. They are written against `core`'s real public API, not
against a mock — the API calls in the tests match the method signatures that actually exist in
`core/src/main/kotlin`, cross-checked by the cross-reference script in Section 3 below.

## 2. Algorithm verification actually executed in this sandbox

Because the real Kotlin tests couldn't run, the three numeric/stateful algorithms in `core` were
independently re-implemented in Python and the resulting script **was actually executed**:

```
$ python3 verify_core_logic.py
PASS: full 7-card lap correctly detected for hog_rider -> 7
PASS: cycle tracker refuses to call the deck complete with only 3 distinct cards seen
PASS: overtime double->triple boundary handled correctly
PASS: duplicate event key is rejected, no double-deduction
PASS: very low confidence detection does not cause a deduction
PASS: elixir clamps to [0, 10]
PASS: saturate->drain->cross-boundary sequence (matches the Kotlin JUnit test) is numerically correct
PASS: regen correctly integrates across the single->double phase boundary: 1.7857 == expected 1.7857
PASS: single-phase regen: 2.8s -> +1.0 elixir, got 1.0

9/9 logic-equivalence checks passed
```

**This verification process found two real bugs before this report was written** — both were bugs
in the first draft of the *test scenarios*, not in the tracked algorithm itself:
1. A phase-boundary test that started from 0 elixir and advanced 119+ seconds of single-phase
   regen — but single-phase regen alone saturates the 10-elixir cap in 28 seconds, so the test was
   asserting a result that the cap made impossible to observe. Fixed by draining elixir back down
   near the boundary before testing the crossing.
2. The same saturation issue recurred in the overtime double→triple boundary test; fixed the same
   way.

Both fixes are reflected in both the Python verification script and the corresponding Kotlin JUnit
test (`ElixirTrackerTest.regen integrates correctly across the single to double phase boundary`),
which deliberately documents the saturation pitfall in a comment so it isn't reintroduced.

## 3. Static consistency checks actually executed in this sandbox

Since no compiler is available, these substitute for (but do not replace) a real compile:

- **Brace/parenthesis balance** across all 22 Kotlin source files: 0 imbalances found.
- **JSON validity** of all 6 JSON files in the project: all parse successfully.
- **Symbol cross-reference**: every class/function name referenced from one file that's expected
  to be declared in another (54 symbols checked, spanning `core` and `app`) resolves to an actual
  declaration somewhere in the project. 0 missing.
- **Package-declaration-vs-directory-path consistency**: all 22 Kotlin files' `package` statements
  match their location on disk. 0 mismatches.
- **Training pipeline dry run**: `training/train_detector.py --epochs 1` was actually executed; it
  correctly detected the absence of a dataset and refused to proceed, rather than fabricating
  output (see its printed output in `docs/LIMITATIONS.md`).

None of these checks is a substitute for `javac`/`kotlinc` actually compiling the code — they catch
a specific, limited class of error (unbalanced braces, dangling references, bad JSON) and do not
catch type errors, incorrect API usage against a real Android/AndroidX/Room/Compose/ONNX Runtime
version, or Gradle configuration problems. The first real compile should be expected to surface
additional issues; none are currently known, but "none known" is not the same claim as "none
exist."

## 4. What spec section 15 asks for that is NOT done

- **Visual recognition test suite** (per-class accuracy, false positives/negatives, confusion
  matrix) — impossible without a trained model (see `docs/LIMITATIONS.md`); not fabricated.
- **Integration test for the full pipeline** — would require a running Android environment
  (emulator or device) that this sandbox does not have.
- **Live Clash Royale manual test procedure** — provided below as the spec explicitly allows
  ("If live Clash Royale testing is not possible in your environment, state that clearly and
  provide a reproducible manual test procedure").

### Manual test procedure (for whoever has a device)

1. Install the debug APK on the target device (or any Android 10+ device).
2. Grant notification + overlay permissions via the in-app buttons.
3. Configure an 8-card deck in Deck Configuration; confirm it persists after force-closing and
   reopening the app (tests Room persistence).
4. Start screen capture while Clash Royale is in the foreground; confirm the persistent
   notification appears and the "Stop capture" action in it actually stops capture (tests
   `CaptureService` lifecycle).
5. Show the floating overlay; confirm it can be dragged, minimized, and hidden (tests
   `OverlayService`).
6. Play a match. Expected current behavior: the overlay shows default placeholder elixir/phase
   values and no detected cards, because no vision model is wired in yet — this is the expected,
   documented state, not a bug to report.
7. Once a trained model is added (see `docs/LIMITATIONS.md`): replay this same procedure and this
   time record, per card class played, whether it was correctly identified, to produce the
   per-class accuracy table spec 15 requires. That table does not exist yet because step 7 hasn't
   happened.
