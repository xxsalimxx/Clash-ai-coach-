#!/usr/bin/env bash
# Copies the source-of-truth JSON databases in /data into the Android app's assets folder.
# Run this after editing cards.json / abilities.json / counters.json in /data.
set -euo pipefail
cd "$(dirname "$0")/.."
cp data/cards.json app/src/main/assets/cards.json
cp data/abilities.json app/src/main/assets/abilities.json
cp data/counters.json app/src/main/assets/counters.json
echo "Synced data/*.json -> app/src/main/assets/"
