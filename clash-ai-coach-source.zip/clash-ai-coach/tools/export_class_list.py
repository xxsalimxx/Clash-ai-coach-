#!/usr/bin/env python3
"""Regenerates training/classes_cards.txt and training/classes_abilities.txt from the JSON
databases in /data, so the training pipeline's class list never drifts from the shipped
card/ability database. Run after editing data/cards.json or data/abilities.json."""
import json
import os

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

cards = json.load(open(os.path.join(ROOT, "data", "cards.json")))["cards"]
abilities = json.load(open(os.path.join(ROOT, "data", "abilities.json")))

with open(os.path.join(ROOT, "training", "classes_cards.txt"), "w") as f:
    for c in sorted(cards, key=lambda c: c["id"]):
        f.write(c["id"] + "\n")

with open(os.path.join(ROOT, "training", "classes_abilities.txt"), "w") as f:
    f.write("no_ability_active\n")
    for a in abilities["champions"]:
        f.write(f"{a['cardId']}_ability\n")
    for a in abilities["heroes"]:
        f.write(f"{a['heroCardId']}_ability\n")

print(f"Wrote {len(cards)} card classes and "
      f"{1 + len(abilities['champions']) + len(abilities['heroes'])} ability classes.")
