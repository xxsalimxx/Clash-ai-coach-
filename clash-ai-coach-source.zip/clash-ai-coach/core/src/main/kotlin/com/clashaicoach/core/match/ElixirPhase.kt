package com.clashaicoach.core.match

/**
 * Elixir regeneration phases, per Supercell's own current rules
 * (support.clashroyale.com/hc/en-us/articles/49484936933403-Elixir, checked
 * live during this project's research, Nov 2026):
 *
 *   Regulation minute 1 (0:00-1:00):   x1 Elixir
 *   Regulation minute 2 (1:00-2:00):   x1 Elixir
 *   Regulation minute 3 (2:00-3:00):   x2 Elixir
 *   Overtime minute 1   (3:00-4:00):   x2 Elixir   (only reached if tied at 3:00)
 *   Overtime minute 2   (4:00-5:00):   x3 Elixir
 *
 * Base rate is 1 Elixir per 2.8s (confirmed independently by Supercell's own
 * support article and by the community-maintained speakerdeck/fandom sources
 * cross-checked during research). x2 halves that interval to 1.4s; x3 cuts
 * it to 2.8/3 = 0.9333...s.
 *
 * NOTE: this models the standard 1v1 ladder ruleset. 2v2 uses a slower base
 * rate (~15% slower per Supercell's support page) and some events/challenges
 * change these numbers outright ("Some Events and modes may have different
 * rulesets" — Supercell's own caveat). [GameMode] lets a caller select the
 * ruleset the detector believes it is observing; defaulting to STANDARD_1V1
 * is deliberate rather than silently assuming every match is standard.
 */
enum class ElixirPhase(val multiplier: Int) { SINGLE(1), DOUBLE(2), TRIPLE(3) }

enum class GameMode(val baseIntervalSeconds: Double) {
    STANDARD_1V1(2.8),
    TWOV2(2.8 / 0.85), // Supercell: "generation is 15% slower than in 1v1"
}

private const val REGULATION_MINUTE_3_START = 120.0
private const val REGULATION_LENGTH = 180.0
private const val OVERTIME_MINUTE_2_START = 60.0 // relative to overtime start
private const val OVERTIME_LENGTH = 120.0

data class MatchClock(
    /** Seconds elapsed since kickoff, 0 at the start of regulation. */
    val regulationElapsedSeconds: Double,
    val isOvertime: Boolean,
    /** Seconds elapsed since overtime started; 0 / ignored when not in overtime. */
    val overtimeElapsedSeconds: Double = 0.0,
) {
    val isMatchOver: Boolean
        get() = isOvertime && overtimeElapsedSeconds >= OVERTIME_LENGTH

    fun phase(): ElixirPhase = when {
        isOvertime && overtimeElapsedSeconds >= OVERTIME_MINUTE_2_START -> ElixirPhase.TRIPLE
        isOvertime -> ElixirPhase.DOUBLE
        regulationElapsedSeconds >= REGULATION_MINUTE_3_START -> ElixirPhase.DOUBLE
        else -> ElixirPhase.SINGLE
    }

    /** Seconds remaining in the *current* phase before the next phase boundary, or null if no further boundary. */
    fun secondsUntilNextPhaseBoundary(): Double? = when {
        isOvertime && overtimeElapsedSeconds < OVERTIME_MINUTE_2_START ->
            OVERTIME_MINUTE_2_START - overtimeElapsedSeconds
        isOvertime -> null // already triple, no further boundary within overtime
        regulationElapsedSeconds < REGULATION_MINUTE_3_START ->
            REGULATION_MINUTE_3_START - regulationElapsedSeconds
        else -> null // regulation double-elixir runs until full time; overtime entry is a separate event, not a timer boundary
    }

    fun advancedBy(deltaSeconds: Double): MatchClock {
        require(deltaSeconds >= 0) { "time does not move backwards" }
        if (isOvertime) {
            return copy(overtimeElapsedSeconds = (overtimeElapsedSeconds + deltaSeconds).coerceAtMost(OVERTIME_LENGTH))
        }
        val newRegulation = regulationElapsedSeconds + deltaSeconds
        return if (newRegulation >= REGULATION_LENGTH) {
            // Caller is responsible for deciding whether the match actually goes to
            // overtime (i.e. it was tied); this clock only tracks time, so crossing
            // 3:00 here just clamps — entering overtime is a deliberate transition
            // via [enterOvertime], not implied by time alone.
            copy(regulationElapsedSeconds = REGULATION_LENGTH)
        } else {
            copy(regulationElapsedSeconds = newRegulation)
        }
    }

    fun enterOvertime(): MatchClock = copy(isOvertime = true, overtimeElapsedSeconds = 0.0)

    companion object {
        fun atKickoff() = MatchClock(regulationElapsedSeconds = 0.0, isOvertime = false)
    }
}
