package com.clashaicoach.core.cycle

/**
 * Clash Royale's cycle rule: a player holds a hand of 4 cards drawn from
 * their 8-card deck; playing a card immediately draws the next card in the
 * deck's cycle order into the hand, and the played card returns to the back
 * of the draw queue. So a card "comes back" after the other 7 deck cards
 * have each been played exactly once since it was last played — NOT a fixed
 * timer. This tracker counts plays-since-last-seen per card, which is the
 * correct proxy for "how soon until this returns" without needing to know
 * elixir spent.
 */
enum class CycleCardStatus { KNOWN_IN_DECK, UNCERTAIN, NOT_YET_SEEN }

data class CyclePlay(
    val cardId: String,
    val timestampSeconds: Double,
    val confidence: Double,
    val playIndex: Int,
)

data class CycleCardEstimate(
    val cardId: String,
    val status: CycleCardStatus,
    /** How many *other distinct* opponent deployments have happened since this card was last played.
     *  Reaches 7 (a full lap) when the card is about to come back up, for a fully known 8-card deck. */
    val playsSinceLastSeen: Int?,
    val lastPlayedAtSeconds: Double?,
    val timesSeenTotal: Int,
)

/**
 * Per spec section 8: never invents missing cards, never assumes the deck is
 * complete ahead of the evidence, and reports confidence per card rather than
 * pretending certainty.
 *
 * The tracker does not assume an 8-card deck is complete until 8 *distinct*
 * cards have actually been observed. Until then, [knownDeckSize] stays null
 * and estimates are reported with [CycleCardStatus.UNCERTAIN] rather than
 * computed against an assumed-complete deck.
 */
class CardCycleTracker {
    private val playHistory = mutableListOf<CyclePlay>()
    private val seenCardIds = LinkedHashSet<String>() // insertion order = discovery order
    private var playCounter = 0

    val knownDeckSize: Int? get() = if (seenCardIds.size >= 8) 8 else null
    val distinctCardsSeen: Int get() = seenCardIds.size
    val fullPlayHistory: List<CyclePlay> get() = playHistory.toList()

    /** Record a confirmed opponent deployment. Call only for deployments the vision layer is
     *  confident were actually a new card play, not a repeat detection of the same unit. */
    fun recordPlay(cardId: String, timestampSeconds: Double, confidence: Double) {
        playCounter++
        playHistory.add(CyclePlay(cardId, timestampSeconds, confidence, playCounter))
        seenCardIds.add(cardId)
        if (seenCardIds.size > 8) {
            // More than 8 distinct cards seen for one opponent is impossible for a legal deck
            // (ignoring Evolutions/Hero swaps, which keep the same base-card identity for cycle
            // purposes). This is a strong signal of a vision mis-identification somewhere in the
            // history; we deliberately do not silently "fix" it by dropping data — callers should
            // surface this via [hasDeckSizeAnomaly] so a human/log can investigate.
        }
    }

    val hasDeckSizeAnomaly: Boolean get() = seenCardIds.size > 8

    /** Best-effort list of the known deck's cards in discovery order (NOT necessarily play/cycle order). */
    fun knownCards(): List<String> = seenCardIds.toList()

    /**
     * Estimate, for every card seen so far, how many *other distinct* opponent cards have been
     * played since it was last seen. A full cycle is 7 (the other 7 deck slots each played once).
     */
    fun estimates(): List<CycleCardEstimate> {
        val lastPlayIndexByCard = HashMap<String, Int>()
        val lastTimestampByCard = HashMap<String, Double>()
        val timesSeenByCard = HashMap<String, Int>()
        for (play in playHistory) {
            lastPlayIndexByCard[play.cardId] = play.playIndex
            lastTimestampByCard[play.cardId] = play.timestampSeconds
            timesSeenByCard[play.cardId] = (timesSeenByCard[play.cardId] ?: 0) + 1
        }
        val deckComplete = knownDeckSize != null
        return seenCardIds.map { cardId ->
            val lastIndex = lastPlayIndexByCard[cardId]
            val distinctSince = if (lastIndex != null) {
                playHistory.filter { it.playIndex > lastIndex }.map { it.cardId }.distinct().size
            } else null
            val status = when {
                !deckComplete -> CycleCardStatus.UNCERTAIN
                else -> CycleCardStatus.KNOWN_IN_DECK
            }
            CycleCardEstimate(
                cardId = cardId,
                status = status,
                playsSinceLastSeen = distinctSince,
                lastPlayedAtSeconds = lastTimestampByCard[cardId],
                timesSeenTotal = timesSeenByCard[cardId] ?: 0,
            )
        }
    }

    /**
     * Cards likely to be back in the opponent's hand "soon" — i.e. at least 5 of the other 7 deck
     * slots have cycled since. Returns an empty list (never a guess) until the deck is fully known,
     * per spec 8 ("do not assume a complete eight-card deck has been identified if the available
     * observations do not support that conclusion").
     */
    fun likelyToReturnSoon(thresholdDistinctPlays: Int = 5): List<CycleCardEstimate> {
        if (knownDeckSize == null) return emptyList()
        return estimates().filter { (it.playsSinceLastSeen ?: 0) >= thresholdDistinctPlays }
            .sortedByDescending { it.playsSinceLastSeen }
    }
}
