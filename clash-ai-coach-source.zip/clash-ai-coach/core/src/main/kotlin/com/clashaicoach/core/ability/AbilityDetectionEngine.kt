package com.clashaicoach.core.ability

import com.clashaicoach.core.db.CardDatabase
import com.clashaicoach.core.model.AbilityUsageModel
import com.clashaicoach.core.model.ArenaSide

enum class VisionSignalType {
    /** The unit was just placed on the arena (card played). */
    DEPLOY_DETECTED,
    /** A single-frame visual cue consistent with an ability activating (button flash, animation start, VFX burst). */
    ABILITY_VISUAL_CUE,
    /** The SAME visual effect still visible on a later frame — evidence of an ongoing effect, not a new trigger. */
    PERSISTENT_EFFECT_VISIBLE,
    /** The tracked unit left the arena (died, or — for Tombstone-style hero plays — transformed). */
    UNIT_REMOVED,
}

data class VisionSignal(
    val trackId: String,
    val cardId: String,
    val side: ArenaSide,
    val type: VisionSignalType,
    val timestampSeconds: Double,
    val confidence: Double,
)

enum class AbilityOutcome {
    /** A genuinely new, confirmed activation — the caller should deduct elixir. */
    CONFIRMED_NEW_ACTIVATION,
    /** Same effect seen again on a later frame; not a new activation, no deduction. */
    REPEATED_FRAME_NOT_NEW,
    /** Ongoing/persistent effect from an earlier confirmed activation; no deduction. */
    PERSISTENT_EFFECT,
    /** A legitimate second (or further) activation under a COOLDOWN usage model (e.g. Boss Bandit). */
    LEGITIMATE_REUSE,
    /** This card has no ability, or isn't a Hero/Champion — nothing to do. */
    NOT_APPLICABLE,
    /** Signal confidence too low, or no prior DEPLOY_DETECTED for this track — can't safely confirm. */
    REJECTED_UNCERTAIN,
}

data class AbilityDecision(
    val outcome: AbilityOutcome,
    val cardId: String,
    val trackId: String,
    val abilityName: String? = null,
    val abilityCost: Int? = null,
    val reason: String? = null,
)

private data class TrackState(
    var deployedAtSeconds: Double,
    var abilityUsedOnce: Boolean = false,
    var lastConfirmedActivationSeconds: Double? = null,
)

/**
 * Implements spec section 5's five-way distinction:
 *   1. Deploying the character            -> tracked, no ability event
 *   2. Activating its ability             -> CONFIRMED_NEW_ACTIVATION
 *   3. A persistent ability effect        -> PERSISTENT_EFFECT
 *   4. A repeated visual effect, not new  -> REPEATED_FRAME_NOT_NEW
 *   5. A legitimate ability reuse         -> LEGITIMATE_REUSE (Boss Bandit only, post-Aug-2026 rules)
 *
 * This class holds per-[VisionSignal.trackId] state so that "same unit, later frame" can be told
 * apart from "new deployment of the same card", which is the vision layer's job (stable track ids),
 * not this engine's — this engine trusts the track id it's given and reasons from there.
 */
class AbilityDetectionEngine(
    private val database: CardDatabase,
    private val minConfidenceToConfirm: Double = 0.55,
    /** How long a visual cue can keep re-triggering a "legitimate reuse" read for COOLDOWN units
     *  before we insist a fresh ABILITY_VISUAL_CUE is required — guards against treating the same
     *  flash as two reuses on consecutive frames. */
    private val cooldownSeconds: Double = 2.5,
) {
    private val trackStates = HashMap<String, TrackState>()

    fun process(signal: VisionSignal): AbilityDecision {
        return when (signal.type) {
            VisionSignalType.DEPLOY_DETECTED -> onDeploy(signal)
            VisionSignalType.ABILITY_VISUAL_CUE -> onAbilityCue(signal)
            VisionSignalType.PERSISTENT_EFFECT_VISIBLE -> onPersistentEffect(signal)
            VisionSignalType.UNIT_REMOVED -> onRemoved(signal)
        }
    }

    private fun onDeploy(signal: VisionSignal): AbilityDecision {
        trackStates[signal.trackId] = TrackState(deployedAtSeconds = signal.timestampSeconds)
        return AbilityDecision(AbilityOutcome.NOT_APPLICABLE, signal.cardId, signal.trackId, reason = "deployment event, not an ability signal")
    }

    private fun onRemoved(signal: VisionSignal): AbilityDecision {
        trackStates.remove(signal.trackId)
        return AbilityDecision(AbilityOutcome.NOT_APPLICABLE, signal.cardId, signal.trackId, reason = "unit removed from play")
    }

    private fun onPersistentEffect(signal: VisionSignal): AbilityDecision {
        val ability = abilityFor(signal.cardId)
            ?: return AbilityDecision(AbilityOutcome.NOT_APPLICABLE, signal.cardId, signal.trackId, reason = "card has no ability")
        return AbilityDecision(AbilityOutcome.PERSISTENT_EFFECT, signal.cardId, signal.trackId, ability.name, ability.cost)
    }

    private fun onAbilityCue(signal: VisionSignal): AbilityDecision {
        val ability = abilityFor(signal.cardId)
            ?: return AbilityDecision(AbilityOutcome.NOT_APPLICABLE, signal.cardId, signal.trackId, reason = "card has no ability")

        if (signal.confidence < minConfidenceToConfirm) {
            return AbilityDecision(AbilityOutcome.REJECTED_UNCERTAIN, signal.cardId, signal.trackId, ability.name, ability.cost,
                reason = "confidence ${signal.confidence} below $minConfidenceToConfirm")
        }

        val state = trackStates[signal.trackId]
            ?: return AbilityDecision(AbilityOutcome.REJECTED_UNCERTAIN, signal.cardId, signal.trackId, ability.name, ability.cost,
                reason = "no prior DEPLOY_DETECTED for track ${signal.trackId}; cannot safely attribute this cue")

        return when (ability.usageModel) {
            AbilityUsageModel.SINGLE_USE_PER_DEPLOYMENT -> {
                if (state.abilityUsedOnce) {
                    AbilityDecision(AbilityOutcome.REPEATED_FRAME_NOT_NEW, signal.cardId, signal.trackId, ability.name, ability.cost,
                        reason = "ability already used once this deployment; later cues are animation frames of the same effect")
                } else {
                    state.abilityUsedOnce = true
                    state.lastConfirmedActivationSeconds = signal.timestampSeconds
                    AbilityDecision(AbilityOutcome.CONFIRMED_NEW_ACTIVATION, signal.cardId, signal.trackId, ability.name, ability.cost)
                }
            }
            AbilityUsageModel.COOLDOWN -> {
                val last = state.lastConfirmedActivationSeconds
                if (last != null && signal.timestampSeconds - last < cooldownSeconds) {
                    AbilityDecision(AbilityOutcome.REPEATED_FRAME_NOT_NEW, signal.cardId, signal.trackId, ability.name, ability.cost,
                        reason = "within cooldown window ($cooldownSeconds s) of last confirmed activation; treat as same trigger")
                } else {
                    val outcome = if (last == null) AbilityOutcome.CONFIRMED_NEW_ACTIVATION else AbilityOutcome.LEGITIMATE_REUSE
                    state.lastConfirmedActivationSeconds = signal.timestampSeconds
                    AbilityDecision(outcome, signal.cardId, signal.trackId, ability.name, ability.cost)
                }
            }
        }
    }

    private data class AbilityInfo(val name: String, val cost: Int, val usageModel: AbilityUsageModel)

    private fun abilityFor(cardId: String): AbilityInfo? {
        database.championAbilityFor(cardId)?.let { return AbilityInfo(it.ability, it.abilityCost, it.usageModel) }
        database.heroAbilityForHero(cardId)?.let { return AbilityInfo(it.ability, it.abilityCost, it.usageModel) }
        return null
    }
}
