package com.clashaicoach.core.model

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

/**
 * One entry in the card database. This mirrors the fields required by
 * spec section 4 ("Card Database"): name, elixir cost, category, type,
 * special attributes, Hero/Champion classification, ability information.
 *
 * [fixedCost] is false for the two cards whose Elixir cost is not a single
 * constant (Mirror, Spirit Empress) — callers must not treat [elixirCost]
 * as authoritative for those without also consulting match context.
 */
@Serializable
data class Card(
    val id: String,
    val name: String,
    val rarity: CardRarity,
    val category: CardCategory,
    val elixirCost: Int,
    @SerialName("fixedCost") val fixedCost: Boolean = true,
    val releaseOrder: Int = 0,
    val hasHeroVariant: Boolean = false,
    val isChampion: Boolean = false,
    val notes: String? = null,
)

enum class AbilityUsageModel { SINGLE_USE_PER_DEPLOYMENT, COOLDOWN }

/** A Champion's ability: belongs to a base card that IS the champion (Archer Queen, etc). */
@Serializable
data class ChampionAbility(
    val cardId: String,
    val ability: String,
    val abilityCost: Int,
    val usageModel: AbilityUsageModel,
    val cooldownSeconds: Double? = null,
    val notes: String? = null,
)

/** A Hero's ability: belongs to the *Hero variant* of a base card (Hero Knight vs Knight). */
@Serializable
data class HeroAbility(
    val cardId: String,
    val heroCardId: String,
    val deployCost: Int,
    val ability: String,
    val abilityCost: Int,
    val usageModel: AbilityUsageModel,
    val released: String? = null,
    val notes: String? = null,
)

@Serializable
data class AbilityGlobalRule(
    val effectiveFrom: String,
    val description: String,
    val exception: String,
)

@Serializable
data class AbilityDatabaseFile(
    val schemaVersion: Int,
    val sourceNote: String,
    val globalRule: AbilityGlobalRule,
    val champions: List<ChampionAbility>,
    val heroes: List<HeroAbility>,
)

@Serializable
data class CardDatabaseFile(
    val schemaVersion: Int,
    val sourceNote: String,
    val cards: List<Card>,
)
