package com.clashaicoach.core.deck

import com.clashaicoach.core.db.CardDatabase

data class PlayerDeck(val cardIds: List<String>) {
    init {
        require(cardIds.size == 8) { "A Clash Royale deck has exactly 8 cards, got ${cardIds.size}" }
        require(cardIds.toSet().size == 8) { "Deck contains duplicate cards: $cardIds" }
    }

    val averageElixirCost: (CardDatabase) -> Double = { db ->
        val costs = cardIds.mapNotNull { db.findCard(it)?.elixirCost }
        if (costs.isEmpty()) 0.0 else costs.sum().toDouble() / costs.size
    }
}

sealed class DeckValidationResult {
    data object Valid : DeckValidationResult()
    data class Invalid(val reasons: List<String>) : DeckValidationResult()
}

object DeckValidator {
    fun validate(cardIds: List<String>, database: CardDatabase): DeckValidationResult {
        val reasons = mutableListOf<String>()
        if (cardIds.size != 8) reasons.add("Deck must have exactly 8 cards (has ${cardIds.size})")
        if (cardIds.toSet().size != cardIds.size) reasons.add("Deck has duplicate cards")
        val unknown = cardIds.filter { database.findCard(it) == null }
        if (unknown.isNotEmpty()) reasons.add("Unknown card id(s): $unknown")
        return if (reasons.isEmpty()) DeckValidationResult.Valid else DeckValidationResult.Invalid(reasons)
    }
}
