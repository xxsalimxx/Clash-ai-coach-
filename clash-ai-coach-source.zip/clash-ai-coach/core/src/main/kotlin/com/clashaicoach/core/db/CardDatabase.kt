package com.clashaicoach.core.db

import com.clashaicoach.core.model.AbilityDatabaseFile
import com.clashaicoach.core.model.Card
import com.clashaicoach.core.model.CardDatabaseFile
import com.clashaicoach.core.model.ChampionAbility
import com.clashaicoach.core.model.HeroAbility
import kotlinx.serialization.json.Json

/**
 * In-memory card + ability database, built from JSON so it can be updated
 * without a code change (spec 4: "Create a mechanism for updating the card
 * database when new cards are released").
 *
 * Update path: call [applyUpdate] with a newer cards.json / abilities.json
 * payload (e.g. downloaded by the app, or bundled in an app update). Entries
 * are merged by [Card.id] / [HeroAbility.heroCardId] / [ChampionAbility.cardId]
 * — a newer entry replaces the older one with the same id, anything else is
 * kept. This intentionally does NOT auto-download from the network: per spec
 * section 17 (privacy) this app does not depend on a mandatory network
 * service, so the default update path is "ship a new JSON file in an app
 * update"; a remote-fetch update source can be layered on top of
 * [applyUpdate] later without changing this class.
 */
class CardDatabase private constructor(
    cardsFile: CardDatabaseFile,
    abilitiesFile: AbilityDatabaseFile,
) {
    private val json = Json { ignoreUnknownKeys = true; prettyPrint = false }

    private val cardsById = cardsFile.cards.associateBy { it.id }.toMutableMap()
    private val championAbilitiesByCardId = abilitiesFile.champions.associateBy { it.cardId }.toMutableMap()
    private val heroAbilitiesByHeroCardId = abilitiesFile.heroes.associateBy { it.heroCardId }.toMutableMap()
    private val heroAbilitiesByBaseCardId = abilitiesFile.heroes.associateBy { it.cardId }.toMutableMap()

    var abilitySingleUseGlobalSince: String = abilitiesFile.globalRule.effectiveFrom
        private set
    var abilitySingleUseException: String = abilitiesFile.globalRule.exception
        private set

    val allCards: List<Card> get() = cardsById.values.toList()
    val cardCount: Int get() = cardsById.size

    fun findCard(id: String): Card? = cardsById[id]
    fun findCardByName(name: String): Card? = cardsById.values.firstOrNull { it.name.equals(name, ignoreCase = true) }

    fun championAbilityFor(cardId: String): ChampionAbility? = championAbilitiesByCardId[cardId]
    fun heroAbilityForHero(heroCardId: String): HeroAbility? = heroAbilitiesByHeroCardId[heroCardId]
    fun heroAbilityForBaseCard(baseCardId: String): HeroAbility? = heroAbilitiesByBaseCardId[baseCardId]

    /**
     * True if [cardId] is a Champion OR a Hero variant with a known ability —
     * i.e. the only cards that can emit an ability-activation event at all.
     */
    fun hasAbility(cardId: String): Boolean =
        championAbilitiesByCardId.containsKey(cardId) || heroAbilitiesByHeroCardId.containsKey(cardId)

    /** Merge a newer card/ability JSON payload into this running database. See class doc. */
    fun applyUpdate(newCardsJson: String? = null, newAbilitiesJson: String? = null): UpdateResult {
        var cardsAdded = 0
        var cardsUpdated = 0
        var abilitiesAdded = 0
        var abilitiesUpdated = 0

        newCardsJson?.let { raw ->
            val parsed = json.decodeFromString(CardDatabaseFile.serializer(), raw)
            parsed.cards.forEach { card ->
                if (cardsById.containsKey(card.id)) cardsUpdated++ else cardsAdded++
                cardsById[card.id] = card
            }
        }
        newAbilitiesJson?.let { raw ->
            val parsed = json.decodeFromString(AbilityDatabaseFile.serializer(), raw)
            parsed.champions.forEach { ab ->
                if (championAbilitiesByCardId.containsKey(ab.cardId)) abilitiesUpdated++ else abilitiesAdded++
                championAbilitiesByCardId[ab.cardId] = ab
            }
            parsed.heroes.forEach { ab ->
                if (heroAbilitiesByHeroCardId.containsKey(ab.heroCardId)) abilitiesUpdated++ else abilitiesAdded++
                heroAbilitiesByHeroCardId[ab.heroCardId] = ab
                heroAbilitiesByBaseCardId[ab.cardId] = ab
            }
            abilitySingleUseGlobalSince = parsed.globalRule.effectiveFrom
            abilitySingleUseException = parsed.globalRule.exception
        }
        return UpdateResult(cardsAdded, cardsUpdated, abilitiesAdded, abilitiesUpdated)
    }

    data class UpdateResult(
        val cardsAdded: Int,
        val cardsUpdated: Int,
        val abilitiesAdded: Int,
        val abilitiesUpdated: Int,
    )

    companion object {
        private val json = Json { ignoreUnknownKeys = true }

        fun load(cardsJson: String, abilitiesJson: String): CardDatabase {
            val cardsFile = json.decodeFromString(CardDatabaseFile.serializer(), cardsJson)
            val abilitiesFile = json.decodeFromString(AbilityDatabaseFile.serializer(), abilitiesJson)
            return CardDatabase(cardsFile, abilitiesFile)
        }
    }
}
