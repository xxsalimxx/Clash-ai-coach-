package com.clashaicoach.core.match

import kotlin.math.max
import kotlin.math.min

/** How sure the vision layer was about the detection that produced an [ElixirEvent]. */
enum class DetectionConfidence(val score: Double) {
    HIGH(0.9), MEDIUM(0.65), LOW(0.4), UNCERTAIN(0.2);

    companion object {
        fun fromScore(score: Double): DetectionConfidence = when {
            score >= 0.8 -> HIGH
            score >= 0.55 -> MEDIUM
            score >= 0.3 -> LOW
            else -> UNCERTAIN
        }
    }
}

enum class ElixirEventType { CARD_DEPLOY, ABILITY_ACTIVATION, NATURAL_REGEN, ELIXIR_GOLEM_GIFT, COLLECTOR_TICK, MANUAL_CORRECTION }

data class ElixirEvent(
    val type: ElixirEventType,
    val delta: Double,
    val timestampSeconds: Double,
    val confidence: DetectionConfidence,
    /** Opaque identity for the thing that caused this event (card id, ability id, track id) — for dedup + UI. */
    val sourceId: String? = null,
    val applied: Boolean,
    val rejectedReason: String? = null,
)

/**
 * Overall trustworthiness of the current elixir estimate. This is deliberately
 * coarse (spec 7: "the application should communicate the uncertainty rather
 * than silently treating the deduction as confirmed") rather than a precise
 * probability, because the uncertainty here is about detection quality, which
 * the vision layer itself only reports coarsely.
 */
enum class EstimateConfidence { EXACT, ESTIMATED, LOW_CONFIDENCE }

/**
 * Tracks one player's (normally the opponent's) estimated Elixir.
 *
 * Usage: caller advances match time with [advanceTime] every tick (or whenever
 * it has a new timestamp from frame processing), and reports deployments /
 * ability activations via [applyDeployment] / [applyAbilityActivation] as the
 * vision pipeline detects them. The tracker:
 *  - never lets elixir go below 0 or above 10 (spec 7 hard requirement)
 *  - applies the correct regen rate for the current phase, including when a
 *    single [advanceTime] call spans a phase boundary
 *  - refuses to apply the same event id twice (dedup against double-counting
 *    the same on-screen deployment across consecutive frames)
 *  - tracks overall [confidence] so the UI can show the estimate is shaky
 *    without hiding a number altogether
 */
class ElixirTracker(
    private val gameMode: GameMode = GameMode.STANDARD_1V1,
    initialElixir: Double = 5.0,
    /** Below this confidence score, a deduction is still applied (we must assume something happened)
     *  but the overall estimate is marked uncertain for the UI. */
    private val uncertainBelow: Double = DetectionConfidence.MEDIUM.score,
    /** Below this confidence score, the event is rejected outright rather than applied — spec 7:
     *  "if a card detection is uncertain ... avoid an unjustified deduction" when it's not even
     *  plausible, as opposed to merely imprecise. */
    private val rejectBelow: Double = DetectionConfidence.UNCERTAIN.score,
    maxEventHistory: Int = 200,
) {
    private var elixir: Double = initialElixir.coerceIn(0.0, 10.0)
    private var clock: MatchClock = MatchClock.atKickoff()
    private val appliedEventKeys = HashSet<String>()
    private val history = ArrayDeque<ElixirEvent>()
    private val maxHistory = maxEventHistory
    private var lowConfidenceEventsSinceReset = 0
    private var totalAppliedEventsSinceReset = 0

    val currentElixir: Double get() = elixir
    val currentPhase: ElixirPhase get() = clock.phase()
    val matchClock: MatchClock get() = clock
    val recentEvents: List<ElixirEvent> get() = history.toList()

    val confidence: EstimateConfidence
        get() = when {
            totalAppliedEventsSinceReset == 0 -> EstimateConfidence.EXACT
            lowConfidenceEventsSinceReset == 0 -> EstimateConfidence.EXACT
            lowConfidenceEventsSinceReset.toDouble() / totalAppliedEventsSinceReset <= 0.15 -> EstimateConfidence.ESTIMATED
            else -> EstimateConfidence.LOW_CONFIDENCE
        }

    /** Advance the match clock by [deltaSeconds] and apply natural regeneration, phase-boundary aware. */
    fun advanceTime(deltaSeconds: Double) {
        require(deltaSeconds >= 0) { "time does not move backwards" }
        var remaining = deltaSeconds
        var working = clock
        while (remaining > 0) {
            val boundary = working.secondsUntilNextPhaseBoundary()
            val step = if (boundary != null) min(boundary, remaining) else remaining
            if (step > 0) {
                val rate = ratePerSecond(working.phase())
                addRegen(step * rate, working.regulationElapsedSeconds + working.overtimeElapsedSeconds)
            }
            working = working.advancedBy(step)
            remaining -= step
            if (step <= 0.0) break // safety: avoid infinite loop if boundary() returns 0 repeatedly
        }
        clock = working
    }

    fun enterOvertime() {
        clock = clock.enterOvertime()
    }

    private fun ratePerSecond(phase: ElixirPhase): Double = phase.multiplier / gameMode.baseIntervalSeconds

    private fun addRegen(amount: Double, timestamp: Double) {
        val before = elixir
        elixir = min(10.0, elixir + amount)
        if (elixir != before) {
            record(ElixirEvent(ElixirEventType.NATURAL_REGEN, elixir - before, timestamp, DetectionConfidence.HIGH, applied = true))
        }
    }

    /**
     * Apply a card deployment deduction. [eventKey] must be stable across repeated detections of the
     * SAME physical deployment (e.g. "opp-deploy-hogrider-142.3s-track7") so that duplicate frames of
     * the same deployment don't double-deduct — spec 4/7 requirement.
     */
    fun applyDeployment(cardId: String, elixirCost: Int, timestampSeconds: Double, confidenceScore: Double, eventKey: String): ElixirEvent =
        applyDeduction(ElixirEventType.CARD_DEPLOY, cardId, elixirCost.toDouble(), timestampSeconds, confidenceScore, eventKey)

    /** Apply a confirmed Hero/Champion ability-activation deduction (spec 5). */
    fun applyAbilityActivation(abilityId: String, elixirCost: Int, timestampSeconds: Double, confidenceScore: Double, eventKey: String): ElixirEvent =
        applyDeduction(ElixirEventType.ABILITY_ACTIVATION, abilityId, elixirCost.toDouble(), timestampSeconds, confidenceScore, eventKey)

    /** Elixir Golem / Golemite / Blob death grants the OPPONENT of whoever owned it 1 Elixir per part. */
    fun applyElixirGift(amount: Double, timestampSeconds: Double, eventKey: String): ElixirEvent {
        if (!appliedEventKeys.add(eventKey)) {
            return rejected(ElixirEventType.ELIXIR_GOLEM_GIFT, amount, timestampSeconds, DetectionConfidence.HIGH, eventKey, "duplicate eventKey")
        }
        val before = elixir
        elixir = min(10.0, elixir + amount)
        return record(ElixirEvent(ElixirEventType.ELIXIR_GOLEM_GIFT, elixir - before, timestampSeconds, DetectionConfidence.HIGH, eventKey, applied = true))
    }

    private fun applyDeduction(
        type: ElixirEventType,
        sourceId: String,
        cost: Double,
        timestampSeconds: Double,
        confidenceScore: Double,
        eventKey: String,
    ): ElixirEvent {
        if (appliedEventKeys.contains(eventKey)) {
            return rejected(type, 0.0, timestampSeconds, DetectionConfidence.fromScore(confidenceScore), sourceId, "duplicate eventKey: $eventKey")
        }
        if (confidenceScore < rejectBelow) {
            return rejected(type, -cost, timestampSeconds, DetectionConfidence.fromScore(confidenceScore), sourceId, "confidence $confidenceScore below reject threshold $rejectBelow")
        }
        appliedEventKeys.add(eventKey)
        val before = elixir
        elixir = max(0.0, elixir - cost) // never negative, per spec 7
        val det = DetectionConfidence.fromScore(confidenceScore)
        totalAppliedEventsSinceReset++
        if (confidenceScore < uncertainBelow) lowConfidenceEventsSinceReset++
        return record(ElixirEvent(type, elixir - before, timestampSeconds, det, sourceId, applied = true))
    }

    private fun rejected(type: ElixirEventType, delta: Double, timestamp: Double, det: DetectionConfidence, sourceId: String?, reason: String): ElixirEvent {
        val event = ElixirEvent(type, delta, timestamp, det, sourceId, applied = false, rejectedReason = reason)
        record(event)
        return event
    }

    private fun record(event: ElixirEvent): ElixirEvent {
        history.addLast(event)
        while (history.size > maxHistory) history.removeFirst()
        return event
    }
}
