package com.clashaicoach.core.coach

import com.clashaicoach.core.db.CardDatabase
import com.clashaicoach.core.deck.PlayerDeck
import com.clashaicoach.core.match.ElixirPhase
import com.clashaicoach.core.match.EstimateConfidence
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json

@Serializable
private data class CounterMatrixFile(val schemaVersion: Int, val sourceNote: String, val counters: Map<String, List<String>>)

data class MatchSituation(
    val opponentLastCardId: String?,
    val opponentLastCardSeconds: Double?,
    val opponentEstimatedElixir: Double,
    val opponentElixirConfidence: EstimateConfidence,
    val opponentElixirPhase: ElixirPhase,
    val playerDeck: PlayerDeck,
    /** Cards currently known to be in the player's hand, if the (optional) player-side recognizer is running. Null = unknown. */
    val playerHandCardIds: List<String>? = null,
)

enum class RecommendationUrgency { INFO, ADVISORY, URGENT }

data class Recommendation(
    val text: String,
    val suggestedCardIds: List<String>,
    val urgency: RecommendationUrgency,
    val basedOn: String,
)

/**
 * Rule-based tactical coach (spec section 10). Deliberately modular: [CounterKnowledgeBase] is a
 * narrow interface so this rule engine can later be replaced or augmented by a learned model without
 * changing [CoachEngine]'s public surface.
 */
interface CounterKnowledgeBase {
    fun countersFor(cardId: String): List<String>

    companion object {
        fun fromJson(json: String): CounterKnowledgeBase {
            val parsed = Json { ignoreUnknownKeys = true }.decodeFromString(CounterMatrixFile.serializer(), json)
            val map = parsed.counters
            return object : CounterKnowledgeBase {
                override fun countersFor(cardId: String): List<String> = map[cardId] ?: emptyList()
            }
        }

        fun empty(): CounterKnowledgeBase = object : CounterKnowledgeBase {
            override fun countersFor(cardId: String): List<String> = emptyList()
        }
    }
}

class CoachEngine(
    private val database: CardDatabase,
    private val knowledgeBase: CounterKnowledgeBase,
) {
    /**
     * Produces at most one recommendation per call. Never suggests a card the player's configured
     * deck does not contain (spec 10 hard requirement), and never states certainty the inputs don't
     * support — a low-confidence elixir estimate is reflected in [Recommendation.basedOn] and the
     * wording, not hidden.
     */
    fun recommend(situation: MatchSituation): Recommendation? {
        val lastCard = situation.opponentLastCardId ?: return genericElixirAdvice(situation)

        val candidateCounters = knowledgeBase.countersFor(lastCard)
        val ownedCounters = candidateCounters.filter { it in situation.playerDeck.cardIds }

        if (ownedCounters.isEmpty()) {
            // No known specific answer in the player's own deck — do not invent one.
            return genericElixirAdvice(situation, note = "no listed counter to ${displayName(lastCard)} in your deck")
        }

        val affordable = situation.playerHandCardIds?.let { hand -> ownedCounters.filter { it in hand } } ?: ownedCounters
        val suggestion = affordable.ifEmpty { ownedCounters }

        val confidenceNote = when (situation.opponentElixirConfidence) {
            EstimateConfidence.EXACT -> ""
            EstimateConfidence.ESTIMATED -> " (elixir estimate approximate)"
            EstimateConfidence.LOW_CONFIDENCE -> " (elixir estimate unreliable right now)"
        }

        val urgency = if (situation.opponentLastCardSeconds != null && situation.opponentElixirPhase != ElixirPhase.SINGLE) {
            RecommendationUrgency.URGENT
        } else {
            RecommendationUrgency.ADVISORY
        }

        val cardNames = suggestion.joinToString(" or ") { displayName(it) }
        return Recommendation(
            text = "Opponent played ${displayName(lastCard)}. Consider: $cardNames$confidenceNote.",
            suggestedCardIds = suggestion,
            urgency = urgency,
            basedOn = "static counter knowledge base + player deck filter",
        )
    }

    private fun genericElixirAdvice(situation: MatchSituation, note: String? = null): Recommendation {
        val text = buildString {
            append("Opponent elixir ~${"%.1f".format(situation.opponentEstimatedElixir)}")
            if (situation.opponentElixirConfidence != EstimateConfidence.EXACT) append(" (estimated)")
            append(". ")
            if (note != null) append("$note. ")
            append(
                when {
                    situation.opponentEstimatedElixir >= 8 -> "Opponent can afford a big push soon — hold a strong defensive answer."
                    situation.opponentEstimatedElixir <= 2 -> "Opponent is low on elixir — a good window to counter-push."
                    else -> "No immediate threat identified; play reactively."
                }
            )
        }
        return Recommendation(
            text = text,
            suggestedCardIds = emptyList(),
            urgency = RecommendationUrgency.INFO,
            basedOn = "elixir-state heuristic",
        )
    }

    private fun displayName(cardId: String): String = database.findCard(cardId)?.name ?: cardId
}
