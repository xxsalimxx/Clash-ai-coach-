package com.clashaicoach.core.model

/**
 * Card rarity. "HERO" and "CHAMPION" are modeled as rarities (matching how
 * Supercell classifies them) rather than as a boolean flag, because a Hero or
 * Champion is a different printing of a base card with its own elixir cost
 * and its own ability, not a modifier on top of the base card's identity.
 */
enum class CardRarity { COMMON, RARE, EPIC, LEGENDARY, CHAMPION, HERO }

enum class CardCategory { TROOP, SPELL, BUILDING, TOWER_TROOP }

/** Ground, air, or both — used to sanity-check vision detections against targeting rules. */
enum class TargetType { GROUND, AIR, GROUND_AND_AIR, BUILDING_ONLY, NONE }

/**
 * Which side of the arena a detection was attributed to. UNKNOWN is a first-class
 * value: per spec section 4, the pipeline must mark a detection as uncertain
 * rather than guess a side when the arena-half classifier is not confident.
 */
enum class ArenaSide { PLAYER, OPPONENT, UNKNOWN }
