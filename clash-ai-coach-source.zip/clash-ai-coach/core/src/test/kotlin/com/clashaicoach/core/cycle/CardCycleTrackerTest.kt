package com.clashaicoach.core.cycle

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertNull
import kotlin.test.assertTrue

class CardCycleTrackerTest {

    @Test
    fun `deck is not considered complete until 8 distinct cards are observed`() {
        val tracker = CardCycleTracker()
        listOf("hog_rider", "ice_golem", "cannon").forEachIndexed { i, id ->
            tracker.recordPlay(id, i.toDouble(), 0.9)
        }
        assertNull(tracker.knownDeckSize)
        assertTrue(tracker.estimates().all { it.status == CycleCardStatus.UNCERTAIN })
    }

    @Test
    fun `a full 7-card lap is detected once the deck is known`() {
        val tracker = CardCycleTracker()
        val deck = listOf("hog_rider", "ice_golem", "cannon", "musketeer", "fireball", "skeletons", "the_log", "zap")
        deck.forEachIndexed { i, id -> tracker.recordPlay(id, i.toDouble(), 0.9) }
        assertEquals(8, tracker.knownDeckSize)

        deck.drop(1).forEachIndexed { i, id -> tracker.recordPlay(id, (10 + i).toDouble(), 0.9) }
        val hogRiderEstimate = tracker.estimates().first { it.cardId == "hog_rider" }
        assertEquals(7, hogRiderEstimate.playsSinceLastSeen)
        assertEquals(CycleCardStatus.KNOWN_IN_DECK, hogRiderEstimate.status)
    }

    @Test
    fun `likelyToReturnSoon is empty until the deck is fully known - never guesses`() {
        val tracker = CardCycleTracker()
        tracker.recordPlay("hog_rider", 0.0, 0.9)
        repeat(6) { i -> tracker.recordPlay("card_$i", (i + 1).toDouble(), 0.9) }
        assertNull(tracker.knownDeckSize) // only 7 distinct cards seen
        assertTrue(tracker.likelyToReturnSoon().isEmpty())
    }

    @Test
    fun `more than 8 distinct cards flags a deck-size anomaly rather than silently continuing`() {
        val tracker = CardCycleTracker()
        (1..9).forEach { i -> tracker.recordPlay("card_$i", i.toDouble(), 0.9) }
        assertTrue(tracker.hasDeckSizeAnomaly)
    }
}
