package com.clashaicoach.core.ability

import com.clashaicoach.core.db.CardDatabase
import com.clashaicoach.core.model.ArenaSide
import kotlin.test.Test
import kotlin.test.assertEquals

private const val TEST_CARDS_JSON = """
{ "schemaVersion": 1, "sourceNote": "test", "cards": [
  { "id": "archer_queen", "name": "Archer Queen", "rarity": "CHAMPION", "category": "TROOP", "elixirCost": 5 },
  { "id": "hero_knight", "name": "Hero Knight", "rarity": "HERO", "category": "TROOP", "elixirCost": 3 },
  { "id": "knight", "name": "Knight", "rarity": "COMMON", "category": "TROOP", "elixirCost": 3 }
]}
"""

private const val TEST_ABILITIES_JSON = """
{ "schemaVersion": 1, "sourceNote": "test",
  "globalRule": { "effectiveFrom": "2026-08-03", "description": "single use except boss bandit", "exception": "boss_bandit" },
  "champions": [
    { "cardId": "archer_queen", "ability": "Cloaking Cape", "abilityCost": 1, "usageModel": "SINGLE_USE_PER_DEPLOYMENT" },
    { "cardId": "boss_bandit", "ability": "Getaway Grenade", "abilityCost": 1, "usageModel": "COOLDOWN", "cooldownSeconds": 3.0 }
  ],
  "heroes": [
    { "cardId": "knight", "heroCardId": "hero_knight", "deployCost": 3, "ability": "Triumphant Taunt", "abilityCost": 2, "usageModel": "SINGLE_USE_PER_DEPLOYMENT" }
  ]
}
"""

class AbilityDetectionEngineTest {

    private fun newEngine(): AbilityDetectionEngine {
        val db = CardDatabase.load(TEST_CARDS_JSON, TEST_ABILITIES_JSON)
        return AbilityDetectionEngine(db)
    }

    @Test
    fun `deploy then ability cue is a confirmed new activation`() {
        val engine = newEngine()
        engine.process(VisionSignal("t1", "archer_queen", ArenaSide.OPPONENT, VisionSignalType.DEPLOY_DETECTED, 0.0, 0.95))
        val decision = engine.process(VisionSignal("t1", "archer_queen", ArenaSide.OPPONENT, VisionSignalType.ABILITY_VISUAL_CUE, 2.0, 0.9))
        assertEquals(AbilityOutcome.CONFIRMED_NEW_ACTIVATION, decision.outcome)
        assertEquals(1, decision.abilityCost)
    }

    @Test
    fun `ability cue with no prior deploy is rejected as uncertain`() {
        val engine = newEngine()
        val decision = engine.process(VisionSignal("t_unknown", "archer_queen", ArenaSide.OPPONENT, VisionSignalType.ABILITY_VISUAL_CUE, 2.0, 0.99))
        assertEquals(AbilityOutcome.REJECTED_UNCERTAIN, decision.outcome)
    }

    @Test
    fun `second ability cue for a single-use ability is a repeated frame, not a new activation`() {
        val engine = newEngine()
        engine.process(VisionSignal("t1", "archer_queen", ArenaSide.OPPONENT, VisionSignalType.DEPLOY_DETECTED, 0.0, 0.95))
        val first = engine.process(VisionSignal("t1", "archer_queen", ArenaSide.OPPONENT, VisionSignalType.ABILITY_VISUAL_CUE, 2.0, 0.9))
        val second = engine.process(VisionSignal("t1", "archer_queen", ArenaSide.OPPONENT, VisionSignalType.ABILITY_VISUAL_CUE, 2.3, 0.9))
        assertEquals(AbilityOutcome.CONFIRMED_NEW_ACTIVATION, first.outcome)
        assertEquals(AbilityOutcome.REPEATED_FRAME_NOT_NEW, second.outcome)
    }

    @Test
    fun `persistent effect signal never deducts even for a fresh deployment`() {
        val engine = newEngine()
        engine.process(VisionSignal("t1", "archer_queen", ArenaSide.OPPONENT, VisionSignalType.DEPLOY_DETECTED, 0.0, 0.95))
        val decision = engine.process(VisionSignal("t1", "archer_queen", ArenaSide.OPPONENT, VisionSignalType.PERSISTENT_EFFECT_VISIBLE, 2.5, 0.9))
        assertEquals(AbilityOutcome.PERSISTENT_EFFECT, decision.outcome)
    }

    @Test
    fun `boss bandit style COOLDOWN ability allows legitimate reuse after the cooldown window`() {
        val db = CardDatabase.load(TEST_CARDS_JSON, TEST_ABILITIES_JSON)
        val engine = AbilityDetectionEngine(db, cooldownSeconds = 3.0)
        engine.process(VisionSignal("t1", "boss_bandit", ArenaSide.OPPONENT, VisionSignalType.DEPLOY_DETECTED, 0.0, 0.95))
        val first = engine.process(VisionSignal("t1", "boss_bandit", ArenaSide.OPPONENT, VisionSignalType.ABILITY_VISUAL_CUE, 1.0, 0.9))
        val tooSoon = engine.process(VisionSignal("t1", "boss_bandit", ArenaSide.OPPONENT, VisionSignalType.ABILITY_VISUAL_CUE, 2.0, 0.9))
        val legitReuse = engine.process(VisionSignal("t1", "boss_bandit", ArenaSide.OPPONENT, VisionSignalType.ABILITY_VISUAL_CUE, 5.0, 0.9))
        assertEquals(AbilityOutcome.CONFIRMED_NEW_ACTIVATION, first.outcome)
        assertEquals(AbilityOutcome.REPEATED_FRAME_NOT_NEW, tooSoon.outcome) // within cooldown window
        assertEquals(AbilityOutcome.LEGITIMATE_REUSE, legitReuse.outcome) // after the cooldown window
    }

    @Test
    fun `hero ability is looked up by the hero card id, deploy cost is not confused with ability cost`() {
        val engine = newEngine()
        engine.process(VisionSignal("t1", "hero_knight", ArenaSide.OPPONENT, VisionSignalType.DEPLOY_DETECTED, 0.0, 0.95))
        val decision = engine.process(VisionSignal("t1", "hero_knight", ArenaSide.OPPONENT, VisionSignalType.ABILITY_VISUAL_CUE, 1.0, 0.9))
        assertEquals(AbilityOutcome.CONFIRMED_NEW_ACTIVATION, decision.outcome)
        assertEquals(2, decision.abilityCost) // ability cost (2), NOT the deploy cost (3)
    }

    @Test
    fun `a card with no ability never produces an ability event`() {
        val engine = newEngine()
        engine.process(VisionSignal("t1", "knight", ArenaSide.OPPONENT, VisionSignalType.DEPLOY_DETECTED, 0.0, 0.95))
        val decision = engine.process(VisionSignal("t1", "knight", ArenaSide.OPPONENT, VisionSignalType.ABILITY_VISUAL_CUE, 1.0, 0.95))
        assertEquals(AbilityOutcome.NOT_APPLICABLE, decision.outcome)
    }
}
