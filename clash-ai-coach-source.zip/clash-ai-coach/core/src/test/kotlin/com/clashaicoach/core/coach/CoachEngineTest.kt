package com.clashaicoach.core.coach

import com.clashaicoach.core.db.CardDatabase
import com.clashaicoach.core.deck.PlayerDeck
import com.clashaicoach.core.match.ElixirPhase
import com.clashaicoach.core.match.EstimateConfidence
import kotlin.test.Test
import kotlin.test.assertFalse
import kotlin.test.assertTrue

private const val CARDS = """
{ "schemaVersion": 1, "sourceNote": "t", "cards": [
  { "id": "pekka", "name": "P.E.K.K.A.", "rarity": "EPIC", "category": "TROOP", "elixirCost": 7 },
  { "id": "inferno_tower", "name": "Inferno Tower", "rarity": "RARE", "category": "BUILDING", "elixirCost": 5 },
  { "id": "mini_pekka", "name": "Mini P.E.K.K.A.", "rarity": "RARE", "category": "TROOP", "elixirCost": 4 },
  { "id": "tesla", "name": "Tesla", "rarity": "COMMON", "category": "BUILDING", "elixirCost": 4 },
  { "id": "knight", "name": "Knight", "rarity": "COMMON", "category": "TROOP", "elixirCost": 3 },
  { "id": "archers", "name": "Archers", "rarity": "COMMON", "category": "TROOP", "elixirCost": 3 },
  { "id": "zap", "name": "Zap", "rarity": "COMMON", "category": "SPELL", "elixirCost": 2 },
  { "id": "skeletons", "name": "Skeletons", "rarity": "COMMON", "category": "TROOP", "elixirCost": 1 }
]}
"""
private const val ABILITIES = """
{ "schemaVersion": 1, "sourceNote": "t", "globalRule": { "effectiveFrom": "2026-08-03", "description": "d", "exception": "boss_bandit" }, "champions": [], "heroes": [] }
"""
private const val COUNTERS = """
{ "schemaVersion": 1, "sourceNote": "t", "counters": { "pekka": ["inferno_tower", "skeleton_army"] } }
"""

class CoachEngineTest {
    private fun engine(): CoachEngine {
        val db = CardDatabase.load(CARDS, ABILITIES)
        val kb = CounterKnowledgeBase.fromJson(COUNTERS)
        return CoachEngine(db, kb)
    }

    private fun deckWith(vararg extra: String): PlayerDeck {
        val base = listOf("knight", "archers", "zap", "skeletons", "mini_pekka", "tesla")
        // Synthetic, deliberately-unknown filler ids — never a real counter to "pekka" in the test
        // counter matrix, so padding the deck to 8 cards can never accidentally satisfy a test
        // that's checking the "no known counter owned" fallback path.
        val fillerPool = listOf("filler_a", "filler_b", "filler_c", "filler_d")
        var cards = (base + extra).distinct()
        var fillerIndex = 0
        while (cards.size < 8) {
            val candidate = fillerPool[fillerIndex % fillerPool.size]
            fillerIndex++
            if (candidate !in cards) cards = cards + candidate
        }
        return PlayerDeck(cards.take(8))
    }

    @Test
    fun `never suggests a card outside the player's configured deck`() {
        val deck = deckWith("inferno_tower") // deck contains inferno_tower, the known counter to pekka
        val situation = MatchSituation(
            opponentLastCardId = "pekka",
            opponentLastCardSeconds = 1.0,
            opponentEstimatedElixir = 5.0,
            opponentElixirConfidence = EstimateConfidence.EXACT,
            opponentElixirPhase = ElixirPhase.SINGLE,
            playerDeck = deck,
        )
        val rec = engine().recommend(situation)!!
        assertTrue(rec.suggestedCardIds.isNotEmpty())
        assertTrue(rec.suggestedCardIds.all { it in deck.cardIds })
    }

    @Test
    fun `falls back to generic advice without inventing a counter the player doesn't own`() {
        val deck = deckWith() // no inferno_tower / skeleton_army in this deck
        val situation = MatchSituation(
            opponentLastCardId = "pekka",
            opponentLastCardSeconds = 1.0,
            opponentEstimatedElixir = 5.0,
            opponentElixirConfidence = EstimateConfidence.EXACT,
            opponentElixirPhase = ElixirPhase.SINGLE,
            playerDeck = deck,
        )
        val rec = engine().recommend(situation)!!
        assertFalse(rec.text.contains("inferno_tower"))
        assertTrue(rec.suggestedCardIds.isEmpty())
    }

    @Test
    fun `low elixir confidence is surfaced in the recommendation text, not hidden`() {
        val deck = deckWith("inferno_tower")
        val situation = MatchSituation(
            opponentLastCardId = "pekka",
            opponentLastCardSeconds = 1.0,
            opponentEstimatedElixir = 5.0,
            opponentElixirConfidence = EstimateConfidence.LOW_CONFIDENCE,
            opponentElixirPhase = ElixirPhase.SINGLE,
            playerDeck = deck,
        )
        val rec = engine().recommend(situation)!!
        assertTrue(rec.text.contains("unreliable"))
    }
}
