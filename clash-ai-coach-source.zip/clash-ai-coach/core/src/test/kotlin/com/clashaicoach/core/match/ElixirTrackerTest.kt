package com.clashaicoach.core.match

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFalse
import kotlin.test.assertTrue

class ElixirTrackerTest {

    @Test
    fun `single phase regen matches 1 elixir per 2-point-8 seconds`() {
        val t = ElixirTracker(initialElixir = 0.0)
        t.advanceTime(2.8)
        assertEquals(1.0, t.currentElixir, 1e-9)
    }

    @Test
    fun `elixir never exceeds 10`() {
        val t = ElixirTracker(initialElixir = 9.5)
        t.advanceTime(50.0)
        assertEquals(10.0, t.currentElixir, 1e-9)
    }

    @Test
    fun `elixir never goes negative on an over-cost deployment`() {
        val t = ElixirTracker(initialElixir = 1.0)
        t.applyDeployment("golem", elixirCost = 8, timestampSeconds = 10.0, confidenceScore = 1.0, eventKey = "k1")
        assertEquals(0.0, t.currentElixir, 1e-9)
    }

    @Test
    fun `duplicate event key does not double-deduct`() {
        val t = ElixirTracker(initialElixir = 10.0)
        val e1 = t.applyDeployment("hog_rider", 4, 142.3, 0.95, "deploy-hogrider-142.3-track7")
        val e2 = t.applyDeployment("hog_rider", 4, 142.4, 0.95, "deploy-hogrider-142.3-track7")
        assertTrue(e1.applied)
        assertFalse(e2.applied)
        assertEquals(6.0, t.currentElixir, 1e-9)
    }

    @Test
    fun `very low confidence detection is rejected, not applied`() {
        val t = ElixirTracker(initialElixir = 10.0)
        val event = t.applyDeployment("mystery_card", 4, 1.0, confidenceScore = 0.05, eventKey = "k1")
        assertFalse(event.applied)
        assertEquals(10.0, t.currentElixir, 1e-9)
    }

    @Test
    fun `ability activation deducts the ability cost not the deploy cost`() {
        val t = ElixirTracker(initialElixir = 10.0)
        // Hero Knight: deploy 3, Triumphant Taunt ability 2 — these must not be conflated.
        t.applyAbilityActivation("hero_knight_taunt", elixirCost = 2, timestampSeconds = 5.0, confidenceScore = 0.9, eventKey = "ability-1")
        assertEquals(8.0, t.currentElixir, 1e-9)
    }

    @Test
    fun `regen integrates correctly across the single to double phase boundary`() {
        // NOTE: the timestamp argument to applyDeployment is event metadata only — it does not
        // drive the tracker's internal clock. The clock only moves via advanceTime(), so the
        // match clock must actually be walked to the 120s boundary with advanceTime() calls.
        val t = ElixirTracker(initialElixir = 0.0)
        t.advanceTime(28.0) // saturates to 10.0 long before the 120s boundary (10 / (1/2.8) = 28s)
        assertEquals(10.0, t.currentElixir, 1e-9)
        t.advanceTime(91.0) // clock now at 119s elapsed; elixir stays capped at 10 (no room to grow)
        assertEquals(10.0, t.currentElixir, 1e-9)

        // Drain elixir so the next regen tick actually has room to show the rate change, then
        // advance across the 120s boundary: 1s left at the single-phase rate, 2s at double.
        t.applyDeployment("golem", elixirCost = 8, timestampSeconds = 119.0, confidenceScore = 1.0, eventKey = "drain")
        val before = t.currentElixir
        assertEquals(2.0, before, 1e-9)
        t.advanceTime(3.0)
        val expectedGain = 1.0 * (1.0 / 2.8) + 2.0 * (2.0 / 2.8)
        assertEquals(expectedGain, t.currentElixir - before, 1e-9)
    }

    @Test
    fun `confidence degrades to ESTIMATED after low-confidence deductions`() {
        val t = ElixirTracker(initialElixir = 10.0, uncertainBelow = 0.6)
        repeat(10) { i -> t.applyDeployment("x", 1, i.toDouble(), confidenceScore = 0.9, eventKey = "hi-$i") }
        assertEquals(EstimateConfidence.EXACT, t.confidence)
        t.applyDeployment("y", 1, 20.0, confidenceScore = 0.4, eventKey = "low-1")
        assertTrue(t.confidence != EstimateConfidence.EXACT)
    }
}
