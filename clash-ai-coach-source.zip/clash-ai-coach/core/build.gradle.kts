// :core is deliberately a pure Kotlin/JVM module, not an Android library module.
// All game-logic — elixir math, card cycle, ability deduction, card/ability
// databases, the recommendation engine — lives here so it can be unit tested
// on a plain JVM (fast, no emulator/device needed) and so the logic has zero
// dependency on Android framework classes. :app depends on :core and wraps it
// with MediaProjection capture, a vision pipeline, a floating overlay and TTS.
plugins {
    kotlin("jvm")
    kotlin("plugin.serialization") version "2.0.21"
}

java {
    sourceCompatibility = JavaVersion.VERSION_17
    targetCompatibility = JavaVersion.VERSION_17
}

dependencies {
    implementation("org.jetbrains.kotlinx:kotlinx-serialization-json:1.7.3")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-core:1.9.0")

    testImplementation(kotlin("test"))
    testImplementation("org.junit.jupiter:junit-jupiter:5.11.3")
    testImplementation("org.junit.jupiter:junit-jupiter-params:5.11.3")
}

tasks.test {
    useJUnitPlatform()
}

kotlin {
    jvmToolchain(17)
}
