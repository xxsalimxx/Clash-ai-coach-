plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
    id("com.google.devtools.ksp")
}

android {
    namespace = "com.clashaicoach.app"
    compileSdk = 35 // Android 15 API level; Android 16 (target device OS) is backward compatible at this compileSdk.
                     // Bump to the Android 16 compileSdk once it is published and verified in Android Studio —
                     // see docs/LIMITATIONS.md, this was not verified live (no network/SDK Manager in this sandbox).

    defaultConfig {
        applicationId = "com.clashaicoach.app"
        minSdk = 29 // Android 10: MediaProjection foreground-service requirements are simplest from here up;
                    // see CaptureService.kt for the per-version branches actually needed down to this floor.
        targetSdk = 35
        versionCode = 1
        versionName = "0.1.0-dev"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
        debug {
            isMinifyEnabled = false
            applicationIdSuffix = ".debug"
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    buildFeatures {
        compose = true
    }
    packaging {
        resources.excludes.add("META-INF/*")
    }
}

dependencies {
    implementation(project(":core"))

    // --- UI ---
    implementation(platform("androidx.compose:compose-bom:2024.10.01"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.foundation:foundation") // LazyVerticalGrid, clickable, etc.
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.activity:activity-compose:1.9.3")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.7")
    implementation("androidx.lifecycle:lifecycle-viewmodel-ktx:2.8.7")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.7")
    // Needed for the overlay Service to act as a LifecycleOwner/ViewModelStoreOwner/
    // SavedStateRegistryOwner so a ComposeView can be hosted from a WindowManager overlay
    // (a bare Service is none of those by default) — see OverlayService.kt.
    implementation("androidx.savedstate:savedstate-ktx:1.2.1")
    debugImplementation("androidx.compose.ui:ui-tooling")

    // --- Core Android ---
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.appcompat:appcompat:1.7.0")

    // --- Persistence (deck configs, match history, card cycle log) ---
    implementation("androidx.room:room-runtime:2.6.1")
    implementation("androidx.room:room-ktx:2.6.1")
    ksp("androidx.room:room-compiler:2.6.1")

    // --- Settings ---
    implementation("androidx.datastore:datastore-preferences:1.1.1")

    // --- On-device inference (spec 2: TFLite / ONNX Runtime Mobile) ---
    // ONNX Runtime chosen over TFLite: lets the same model format be trained/exported from
    // either PyTorch or TF without a conversion step, and onnxruntime-android ships NNAPI +
    // XNNPACK execution providers out of the box for the target device's Snapdragon/Dimensity
    // class SoCs. See core vision module notes — NO TRAINED MODEL SHIPS YET (spec 14 honesty
    // requirement); this dependency wires up the inference *path*, not a working detector.
    implementation("com.microsoft.onnxruntime:onnxruntime-android:1.19.2")

    // --- JSON for card/ability database + deck config persistence ---
    implementation("org.jetbrains.kotlinx:kotlinx-serialization-json:1.7.3")

    testImplementation("junit:junit:4.13.2")
    androidTestImplementation("androidx.test.ext:junit:1.2.1")
    androidTestImplementation("androidx.test.espresso:espresso-core:3.6.1")
}
