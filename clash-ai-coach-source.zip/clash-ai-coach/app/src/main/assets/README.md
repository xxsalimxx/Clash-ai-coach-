These are copies of /data/*.json at the project root. /data is the single source of truth
(edited by tools/ scripts); these copies are what actually ships in the APK. Keep them in sync —
`tools/sync_assets.sh` copies /data/*.json here; run it after editing anything in /data.
