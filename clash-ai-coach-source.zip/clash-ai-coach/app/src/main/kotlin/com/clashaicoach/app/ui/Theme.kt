package com.clashaicoach.app.ui

import androidx.compose.material3.darkColorScheme
import androidx.compose.ui.graphics.Color

/** Spec 13: "Create a professional, clean, dark-themed interface." */
fun darkClashTheme() = darkColorScheme(
    primary = Color(0xFF6C9BFF),
    onPrimary = Color(0xFF07122B),
    secondary = Color(0xFFFFC266),
    background = Color(0xFF0B0B10),
    onBackground = Color(0xFFEAEAF0),
    surface = Color(0xFF15151C),
    onSurface = Color(0xFFEAEAF0),
    error = Color(0xFFFF6B6B),
)
