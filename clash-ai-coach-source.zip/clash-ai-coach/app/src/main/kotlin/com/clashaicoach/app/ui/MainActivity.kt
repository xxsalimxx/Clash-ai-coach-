package com.clashaicoach.app.ui

import android.annotation.SuppressLint
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.clashaicoach.app.capture.CaptureService
import com.clashaicoach.app.capture.CaptureStatus
import com.clashaicoach.app.capture.CaptureStatusBus
import com.clashaicoach.app.overlay.OverlayService

/**
 * Hosts the permission flow spec sections 3/11/13 require:
 *  1. POST_NOTIFICATIONS (Android 13+) — required before a foreground service's status
 *     notification can actually show.
 *  2. SYSTEM_ALERT_WINDOW ("draw over other apps") — has no runtime dialog; the user must grant
 *     it from a Settings screen the system itself provides, which this activity launches and then
 *     re-checks on resume.
 *  3. The MediaProjection consent dialog — must be re-requested every time capture (re)starts; the
 *     resulting Intent + result code is forwarded directly into [CaptureService] (see that class's
 *     doc on why the token cannot be cached/reused).
 *
 * The UI below is intentionally minimal (Home + a status readout) — this is the functional
 * foundation for spec 13's nine-screen navigation; only Home and the entry points that matter for
 * actually starting capture/overlay are implemented end-to-end here. See
 * app/src/main/kotlin/.../ui/DeckConfigScreen.kt for the second implemented screen and
 * docs/LIMITATIONS.md for which of the remaining seven screens are stubs vs not yet started.
 */
class MainActivity : ComponentActivity() {

    private val mediaProjectionManager by lazy { getSystemService(MediaProjectionManager::class.java) }

    private val notificationPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission(),
    ) { /* result observed via hasNotificationPermission() on next recomposition trigger */ }

    private val overlayPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult(),
    ) { /* re-checked via Settings.canDrawOverlays on resume */ }

    private val mediaProjectionLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult(),
    ) { result ->
        if (result.resultCode == RESULT_OK && result.data != null) {
            val intent = Intent(this, CaptureService::class.java).apply {
                putExtra(CaptureService.EXTRA_RESULT_CODE, result.resultCode)
                putExtra(CaptureService.EXTRA_RESULT_DATA, result.data)
            }
            startForegroundService(intent)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkClashTheme()) {
                Surface(modifier = Modifier.fillMaxSize()) {
                    HomeScreen(
                        hasOverlayPermission = { canDrawOverlays() },
                        hasNotificationPermission = { hasNotificationPermission() },
                        onRequestNotificationPermission = { requestNotificationPermissionIfNeeded() },
                        onRequestOverlayPermission = { requestOverlayPermission() },
                        onStartCapture = { requestMediaProjection() },
                        onStopCapture = { stopCapture() },
                        onStartOverlay = { startForegroundService(Intent(this, OverlayService::class.java)) },
                    )
                }
            }
        }
    }

    private fun requestMediaProjection() {
        mediaProjectionLauncher.launch(mediaProjectionManager.createScreenCaptureIntent())
    }

    private fun stopCapture() {
        startService(Intent(this, CaptureService::class.java).apply { action = CaptureService.ACTION_STOP })
    }

    private fun canDrawOverlays(): Boolean =
        Build.VERSION.SDK_INT < Build.VERSION_CODES.M || Settings.canDrawOverlays(this)

    private fun requestOverlayPermission() {
        if (canDrawOverlays()) return
        val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
        overlayPermissionLauncher.launch(intent)
    }

    private fun hasNotificationPermission(): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) return true
        return checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) ==
            android.content.pm.PackageManager.PERMISSION_GRANTED
    }

    private fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) return
        if (!hasNotificationPermission()) {
            notificationPermissionLauncher.launch(android.Manifest.permission.POST_NOTIFICATIONS)
        }
    }
}

@SuppressLint("ComposableNaming")
@androidx.compose.runtime.Composable
private fun HomeScreen(
    hasOverlayPermission: () -> Boolean,
    hasNotificationPermission: () -> Boolean,
    onRequestNotificationPermission: () -> Unit,
    onRequestOverlayPermission: () -> Unit,
    onStartCapture: () -> Unit,
    onStopCapture: () -> Unit,
    onStartOverlay: () -> Unit,
) {
    var captureStatus by remember { mutableStateOf(CaptureStatusBus.current) }
    androidx.compose.runtime.DisposableEffect(Unit) {
        val listener: (CaptureStatus) -> Unit = { captureStatus = it }
        CaptureStatusBus.observe(listener)
        onDispose { CaptureStatusBus.removeObserver(listener) }
    }

    Column(
        modifier = Modifier.fillMaxSize().padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        Text("Clash AI Coach", style = MaterialTheme.typography.headlineMedium)
        Text("Observation-only match assistant. This app never plays cards for you.")

        Text("Capture status: ${captureStatus::class.simpleName}")

        if (!hasNotificationPermission()) {
            Button(onClick = onRequestNotificationPermission) { Text("Grant notification permission") }
        }
        if (!hasOverlayPermission()) {
            Button(onClick = onRequestOverlayPermission) { Text("Grant 'draw over other apps' permission") }
        }

        Button(onClick = onStartCapture, enabled = hasNotificationPermission()) {
            Text("Start screen capture")
        }
        Button(onClick = onStopCapture) { Text("Stop screen capture") }
        Button(onClick = onStartOverlay, enabled = hasOverlayPermission()) { Text("Show floating overlay") }
    }
}
