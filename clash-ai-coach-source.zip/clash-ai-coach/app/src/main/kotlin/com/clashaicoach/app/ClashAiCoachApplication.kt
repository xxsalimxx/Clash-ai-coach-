package com.clashaicoach.app

import android.app.Application
import com.clashaicoach.core.coach.CoachEngine
import com.clashaicoach.core.coach.CounterKnowledgeBase
import com.clashaicoach.core.db.CardDatabase

/**
 * Loads the bundled card/ability/counter JSON once at process start. These files live in
 * app/src/main/assets (copied from /data in the project root — see app/src/main/assets/README.md)
 * so they can be replaced by an app update without touching code, satisfying spec 4's
 * "mechanism for updating the database when new cards are released": ship a new assets/cards.json
 * and/or assets/abilities.json in a new APK, or call [CardDatabase.applyUpdate] at runtime with
 * JSON fetched by a future update-check feature (not implemented — see docs/LIMITATIONS.md).
 */
class ClashAiCoachApplication : Application() {

    lateinit var cardDatabase: CardDatabase
        private set
    lateinit var coachEngine: CoachEngine
        private set

    override fun onCreate() {
        super.onCreate()
        val cardsJson = assets.open("cards.json").bufferedReader().use { it.readText() }
        val abilitiesJson = assets.open("abilities.json").bufferedReader().use { it.readText() }
        val countersJson = assets.open("counters.json").bufferedReader().use { it.readText() }

        cardDatabase = CardDatabase.load(cardsJson, abilitiesJson)
        coachEngine = CoachEngine(cardDatabase, CounterKnowledgeBase.fromJson(countersJson))
    }
}
