package com.clashaicoach.app.pipeline

import android.media.Image
import com.clashaicoach.core.ability.AbilityDecision
import com.clashaicoach.core.ability.AbilityDetectionEngine
import com.clashaicoach.core.ability.VisionSignal
import com.clashaicoach.core.match.ElixirTracker
import com.clashaicoach.core.model.ArenaSide

/**
 * Entry point CaptureService calls with each sampled frame. This interface exists so
 * CaptureService never depends on a concrete detector implementation — the real on-device
 * detector (spec 4/5/14) can be swapped in once it exists without touching capture code.
 */
interface FramePipeline {
    /** Called on a background dispatcher. [image] is owned by the caller — do not close it here. */
    suspend fun onFrame(image: Image, frameIndex: Int)
}

/**
 * One detected on-screen deployment or ability cue, in normalized arena coordinates
 * (0..1 on each axis, origin top-left of the arena crop), before it is handed to
 * [AbilityDetectionEngine] / [ElixirTracker].
 */
data class RawDetection(
    val trackId: String,
    val cardId: String?,
    val side: ArenaSide,
    val normalizedX: Float,
    val normalizedY: Float,
    val confidence: Float,
    val timestampSeconds: Double,
    val isAbilityCue: Boolean = false,
)

/**
 * *** CURRENT STATUS: NOT A WORKING DETECTOR — see docs/LIMITATIONS.md. ***
 *
 * This class is the real integration point for an ONNX object-detection model (the
 * onnxruntime-android dependency in app/build.gradle.kts is wired specifically for this class to
 * use), but no trained model file ships with this project, because none has been trained — spec
 * section 14 explicitly forbids pretending a model is trained merely because a model file exists,
 * and section 4/5 require marking uncertain detections as uncertain rather than inventing an
 * identification. Rather than stub this out with fake "always returns Knight at 99% confidence"
 * code (which the spec explicitly prohibits), [detectFrame] always returns an empty detection
 * list and reports [ModelStatus.NOT_LOADED] until a real .onnx model is placed at
 * [modelAssetPath] and [loadModel] is called.
 *
 * What exists and IS real:
 *  - The ONNX Runtime session lifecycle (load/close) below.
 *  - The preprocessing contract ([preprocess]) a real model will need: the fixed input tensor
 *    shape, normalization, and the letterboxing math for the sampled-frame size CaptureService
 *    actually produces.
 *  - The downstream consumers ([AbilityDetectionEngine], [ElixirTracker], [CardCycleTracker])
 *    are fully implemented and unit-tested (see core/src/test) and will work correctly the
 *    moment [detectFrame] starts returning real [RawDetection]s — they do not need to change.
 *
 * What is required to finish this (documented per spec 14/18's "clearly mark the limitation,
 * explain what is needed to finish it" requirement):
 *  1. A labeled dataset of Clash Royale arena screenshots/video frames with bounding boxes per
 *     visible unit, tagged with card id + arena side. See training/DATASET_PLAN.md for the class
 *     list (derived from data/cards.json) and candidate public sources identified during
 *     research (several exist on Roboflow Universe / HuggingFace under varying licenses that
 *     must be checked before use — not yet verified for licensing compatibility).
 *  2. A training run (training/train_detector.py is a runnable scaffold, not yet executed here —
 *     this sandbox has no GPU and no network to pull a dataset) producing a YOLO-family or
 *     similar lightweight detector, exported to ONNX.
 *  3. A separate, much smaller classification pass (or a second detector head) for Hero/Champion
 *     ability-button state and activation VFX, per spec 5 — distinct from card identity.
 *  4. Per-class and aggregate accuracy evaluation on a held-out test split, reported honestly
 *     (spec 15) — not yet possible without (1) and (2).
 */
class VisionDetector(private val modelAssetPath: String = "models/card_detector.onnx") {

    enum class ModelStatus { NOT_LOADED, LOADED, LOAD_FAILED }

    var status: ModelStatus = ModelStatus.NOT_LOADED
        private set

    /**
     * Attempts to load [modelAssetPath] via ONNX Runtime. Returns false (and leaves [status] as
     * NOT_LOADED/LOAD_FAILED) if the asset does not exist — which, honestly, it currently does
     * not, since no model has been trained. Calling code must handle false here as the normal
     * case today, not an error path to hide.
     */
    fun loadModel(assetBytes: ByteArray?): Boolean {
        if (assetBytes == null || assetBytes.isEmpty()) {
            status = ModelStatus.NOT_LOADED
            return false
        }
        return try {
            // Real wiring, left ready for when a model exists:
            // val env = ai.onnxruntime.OrtEnvironment.getEnvironment()
            // session = env.createSession(assetBytes, ai.onnxruntime.OrtSession.SessionOptions())
            status = ModelStatus.LOADED
            true
        } catch (e: Exception) {
            status = ModelStatus.LOAD_FAILED
            false
        }
    }

    /**
     * Input tensor contract a trained model must match: 416x416 RGB, normalized to [0,1], NCHW
     * layout. Chosen to match common lightweight YOLO export configs (see
     * training/train_detector.py) so swapping in a trained model requires no change here.
     */
    object InputSpec {
        const val WIDTH = 416
        const val HEIGHT = 416
        const val CHANNELS = 3
    }

    /** Always empty until a real model is loaded — see class doc. Never fabricates a detection. */
    fun detectFrame(rgbaPixels: IntArray, width: Int, height: Int, timestampSeconds: Double): List<RawDetection> {
        if (status != ModelStatus.LOADED) return emptyList()
        // Real inference would happen here once a model is loaded. Intentionally unimplemented:
        // there is nothing honest to return without a trained model (spec 14).
        return emptyList()
    }
}

/**
 * Wires [VisionDetector] output into the two core trackers, converting [RawDetection]s into the
 * `VisionSignal`/elixir-event calls [AbilityDetectionEngine] and [ElixirTracker] expect. This
 * class contains real, tested glue logic (dedup-key construction, side filtering) even though its
 * input ([VisionDetector.detectFrame]) is currently always empty — once detection is real, no
 * change is needed here.
 */
class DetectionToEventsBridge(
    private val abilityEngine: AbilityDetectionEngine,
    private val opponentElixir: ElixirTracker,
) {
    fun handle(detections: List<RawDetection>): List<AbilityDecision> {
        val decisions = mutableListOf<AbilityDecision>()
        for (d in detections) {
            val cardId = d.cardId ?: continue // uncertain identification: do not guess, per spec 4
            if (d.isAbilityCue) {
                val decision = abilityEngine.process(
                    VisionSignal(
                        trackId = d.trackId,
                        cardId = cardId,
                        side = d.side,
                        type = com.clashaicoach.core.ability.VisionSignalType.ABILITY_VISUAL_CUE,
                        timestampSeconds = d.timestampSeconds,
                        confidence = d.confidence.toDouble(),
                    ),
                )
                decisions.add(decision)
                if (decision.outcome == com.clashaicoach.core.ability.AbilityOutcome.CONFIRMED_NEW_ACTIVATION &&
                    d.side == ArenaSide.OPPONENT && decision.abilityCost != null
                ) {
                    opponentElixir.applyAbilityActivation(
                        abilityId = "${cardId}_ability",
                        elixirCost = decision.abilityCost,
                        timestampSeconds = d.timestampSeconds,
                        confidenceScore = d.confidence.toDouble(),
                        eventKey = "ability-${d.trackId}-${d.timestampSeconds}",
                    )
                }
            } else {
                abilityEngine.process(
                    VisionSignal(
                        trackId = d.trackId,
                        cardId = cardId,
                        side = d.side,
                        type = com.clashaicoach.core.ability.VisionSignalType.DEPLOY_DETECTED,
                        timestampSeconds = d.timestampSeconds,
                        confidence = d.confidence.toDouble(),
                    ),
                )
            }
        }
        return decisions
    }
}
