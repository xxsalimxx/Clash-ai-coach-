package com.clashaicoach.app.overlay

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.ExperimentalComposeUiApi
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInteropFilter
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.unit.dp
import androidx.core.app.NotificationCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.LifecycleRegistry
import androidx.lifecycle.ViewModelStore
import androidx.lifecycle.ViewModelStoreOwner
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.lifecycle.setViewTreeViewModelStoreOwner
import androidx.savedstate.SavedStateRegistry
import androidx.savedstate.SavedStateRegistryController
import androidx.savedstate.SavedStateRegistryOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import com.clashaicoach.app.R
import com.clashaicoach.core.coach.Recommendation
import com.clashaicoach.core.match.ElixirPhase
import com.clashaicoach.core.match.EstimateConfidence

/**
 * Floating overlay window, per spec section 11. Requirements covered here:
 *  - user-controlled positioning: drag-to-move via the raw touch listener on the root view
 *    (WindowManager overlays can't use Compose's pointerInput drag gestures cleanly across a
 *    window boundary, so this uses the classic onTouchListener + updateViewLayout approach)
 *  - minimize/maximize: [isMinimized] collapses the card to a small pill
 *  - hide: [hide] removes the view and stops the service
 *  - low resource consumption: the overlay only recomposes on actual state pushes from
 *    [OverlayStateBus]; it does not poll
 *
 * This requires the SYSTEM_ALERT_WINDOW ("draw over other apps") permission, granted via the
 * Settings screen the system forces apps to (there is no runtime permission dialog for it);
 * MainActivity's permission flow checks Settings.canDrawOverlays before starting this service.
 */
class OverlayService :
    Service(),
    LifecycleOwner,
    ViewModelStoreOwner,
    SavedStateRegistryOwner {

    companion object {
        const val NOTIFICATION_CHANNEL_ID = "overlay_status"
        const val NOTIFICATION_ID = 1002
    }

    private val lifecycleRegistry = LifecycleRegistry(this)
    override val lifecycle: Lifecycle get() = lifecycleRegistry
    override val viewModelStore = ViewModelStore()
    private val savedStateRegistryController = SavedStateRegistryController.create(this)
    override val savedStateRegistry: SavedStateRegistry get() = savedStateRegistryController.savedStateRegistry

    private var windowManager: WindowManager? = null
    private var composeView: ComposeView? = null
    private var layoutParams: WindowManager.LayoutParams? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        savedStateRegistryController.performAttach()
        savedStateRegistryController.performRestore(null)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_CREATE)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_START)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_RESUME)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        ensureNotificationChannel()
        startForeground(NOTIFICATION_ID, buildNotification())
        if (composeView == null) showOverlay()
        return START_STICKY
    }

    private fun showOverlay() {
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        windowManager = wm

        val overlayType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT,
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 24
            y = 150
        }
        layoutParams = params

        val view = ComposeView(this).apply {
            setViewTreeLifecycleOwner(this@OverlayService)
            setViewTreeViewModelStoreOwner(this@OverlayService)
            setViewTreeSavedStateRegistryOwner(this@OverlayService)
            setContent {
                OverlayRoot(
                    onDragDelta = { dx, dy -> moveBy(dx, dy) },
                    onHide = { hide() },
                )
            }
        }
        composeView = view
        wm.addView(view, params)
    }

    private fun moveBy(dx: Float, dy: Float) {
        val params = layoutParams ?: return
        params.x += dx.toInt()
        params.y += dy.toInt()
        windowManager?.updateViewLayout(composeView, params)
    }

    private fun hide() {
        composeView?.let { windowManager?.removeView(it) }
        composeView = null
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        composeView?.let { windowManager?.removeView(it) }
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_DESTROY)
        viewModelStore.clear()
        super.onDestroy()
    }

    private fun ensureNotificationChannel() {
        val manager = getSystemService(NotificationManager::class.java)
        manager.createNotificationChannel(
            NotificationChannel(NOTIFICATION_CHANNEL_ID, "Overlay status", NotificationManager.IMPORTANCE_LOW),
        )
    }

    private fun buildNotification() = NotificationCompat.Builder(this, NOTIFICATION_CHANNEL_ID)
        .setContentTitle("Clash AI Coach overlay")
        .setContentText("Tap to hide the overlay from the app")
        .setSmallIcon(R.drawable.ic_capture_status)
        .setOngoing(true)
        .build()
}

/** Latest data the overlay should render. Pushed from the pipeline/coach engine, never polled. */
data class OverlayState(
    val opponentElixir: Double = 5.0,
    val elixirConfidence: EstimateConfidence = EstimateConfidence.EXACT,
    val elixirPhase: ElixirPhase = ElixirPhase.SINGLE,
    val recentOpponentCards: List<String> = emptyList(),
    val latestRecommendation: Recommendation? = null,
)

object OverlayStateBus {
    @Volatile var current: OverlayState = OverlayState()
    private val listeners = mutableListOf<(OverlayState) -> Unit>()
    fun push(state: OverlayState) {
        current = state
        listeners.forEach { it(state) }
    }
    fun observe(listener: (OverlayState) -> Unit) {
        listeners.add(listener)
        listener(current)
    }
    fun removeObserver(listener: (OverlayState) -> Unit) {
        listeners.remove(listener)
    }
}

@OptIn(ExperimentalComposeUiApi::class)
@androidx.compose.runtime.Composable
private fun OverlayRoot(onDragDelta: (Float, Float) -> Unit, onHide: () -> Unit) {
    var minimized by remember { mutableStateOf(false) }
    var state by remember { mutableStateOf(OverlayStateBus.current) }
    DisposableEffect(Unit) {
        val listener: (OverlayState) -> Unit = { state = it }
        OverlayStateBus.observe(listener)
        onDispose { OverlayStateBus.removeObserver(listener) }
    }

    // Raw touch tracking for drag-to-move: a WindowManager overlay window cannot rely on
    // Compose's own pointerInput drag-gesture detection crossing cleanly with window
    // translation, so this uses the classic View touch deltas instead, same as most
    // floating-overlay implementations on Android.
    var lastTouchX by remember { mutableStateOf(0f) }
    var lastTouchY by remember { mutableStateOf(0f) }
    val dragModifier = Modifier.pointerInteropFilter { event ->
        when (event.action) {
            MotionEvent.ACTION_DOWN -> { lastTouchX = event.rawX; lastTouchY = event.rawY; true }
            MotionEvent.ACTION_MOVE -> {
                val dx = event.rawX - lastTouchX
                val dy = event.rawY - lastTouchY
                lastTouchX = event.rawX; lastTouchY = event.rawY
                onDragDelta(dx, dy)
                true
            }
            else -> false
        }
    }

    MaterialTheme {
        Column(
            modifier = Modifier
                .clip(RoundedCornerShape(12.dp))
                .background(Color(0xCC101014))
                .then(dragModifier)
                .padding(10.dp),
        ) {
            Row(horizontalArrangement = Arrangement.SpaceBetween) {
                Text("⚡ Clash AI Coach", color = Color.White)
                Text(
                    if (minimized) " ▸" else " ▾",
                    color = Color.White,
                    modifier = Modifier.clickable { minimized = !minimized },
                )
                Text(" ✕", color = Color(0xFFFF6B6B), modifier = Modifier.clickable { onHide() })
            }
            if (!minimized) {
                Text(
                    "Opp elixir: ${"%.1f".format(state.opponentElixir)}" +
                        if (state.elixirConfidence != EstimateConfidence.EXACT) " (est.)" else "",
                    color = Color(0xFFBBDEFB),
                )
                Text("Phase: ${state.elixirPhase}", color = Color(0xFFBBDEFB))
                if (state.recentOpponentCards.isNotEmpty()) {
                    Text("Recent: ${state.recentOpponentCards.takeLast(3).joinToString(", ")}", color = Color.White)
                }
                state.latestRecommendation?.let {
                    Text(it.text, color = Color(0xFFFFE082))
                }
            }
        }
    }
}
