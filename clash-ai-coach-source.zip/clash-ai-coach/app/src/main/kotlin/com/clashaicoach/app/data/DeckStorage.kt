package com.clashaicoach.app.data

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.Upsert
import kotlinx.coroutines.flow.Flow

/**
 * A saved player deck (spec 9: "Save and load configurations"). [cardIdsCsv] stores the 8 card
 * ids as a comma-separated string rather than a related table — a deck is always read/written as
 * a whole unit, so normalizing it into a child table would only add join overhead with no benefit.
 */
@Entity(tableName = "saved_decks")
data class SavedDeckEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val cardIdsCsv: String,
    val isActive: Boolean = false,
    val createdAtEpochMillis: Long,
) {
    fun cardIds(): List<String> = cardIdsCsv.split(",").filter { it.isNotBlank() }

    companion object {
        fun from(name: String, cardIds: List<String>, isActive: Boolean, now: Long): SavedDeckEntity {
            require(cardIds.size == 8) { "A deck must have exactly 8 cards" }
            return SavedDeckEntity(name = name, cardIdsCsv = cardIds.joinToString(","), isActive = isActive, createdAtEpochMillis = now)
        }
    }
}

@Dao
interface DeckDao {
    @Query("SELECT * FROM saved_decks ORDER BY createdAtEpochMillis DESC")
    fun observeAll(): Flow<List<SavedDeckEntity>>

    @Query("SELECT * FROM saved_decks WHERE isActive = 1 LIMIT 1")
    suspend fun getActive(): SavedDeckEntity?

    @Upsert
    suspend fun upsert(deck: SavedDeckEntity): Long

    @Query("UPDATE saved_decks SET isActive = 0")
    suspend fun clearActiveFlag()

    @Query("UPDATE saved_decks SET isActive = 1 WHERE id = :id")
    suspend fun markActive(id: Long)

    @Query("DELETE FROM saved_decks WHERE id = :id")
    suspend fun delete(id: Long)
}

@Database(entities = [SavedDeckEntity::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun deckDao(): DeckDao

    companion object {
        @Volatile private var instance: AppDatabase? = null

        fun get(context: Context): AppDatabase =
            instance ?: synchronized(this) {
                instance ?: Room.databaseBuilder(context.applicationContext, AppDatabase::class.java, "clash_ai_coach.db")
                    .build()
                    .also { instance = it }
            }
    }
}

/** Convenience wrapper used by the UI layer; keeps transaction-shaped logic (set-active) in one place. */
class DeckRepository(private val dao: DeckDao) {
    fun observeDecks(): Flow<List<SavedDeckEntity>> = dao.observeAll()

    suspend fun saveAndActivate(name: String, cardIds: List<String>) {
        dao.clearActiveFlag()
        dao.upsert(SavedDeckEntity.from(name, cardIds, isActive = true, now = System.currentTimeMillis()))
    }

    suspend fun setActive(id: Long) {
        dao.clearActiveFlag()
        dao.markActive(id)
    }

    suspend fun delete(id: Long) = dao.delete(id)

    suspend fun getActiveDeck(): SavedDeckEntity? = dao.getActive()
}
