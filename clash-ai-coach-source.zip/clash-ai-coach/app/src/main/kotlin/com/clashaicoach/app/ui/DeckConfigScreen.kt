package com.clashaicoach.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.clashaicoach.app.data.DeckRepository
import com.clashaicoach.core.db.CardDatabase
import com.clashaicoach.core.deck.DeckValidationResult
import com.clashaicoach.core.deck.DeckValidator
import kotlinx.coroutines.launch

/**
 * Spec section 9: card selection, elixir costs shown per card, deck editing, save/load. Automatic
 * recognition of the player's own cards from the game screen is listed in the spec as optional and
 * is NOT implemented (it would reuse the same not-yet-trained detector described in
 * app/.../pipeline/FramePipeline.kt — see docs/LIMITATIONS.md); manual selection here is fully
 * functional on its own.
 */
@Composable
fun DeckConfigScreen(
    cardDatabase: CardDatabase,
    deckRepository: DeckRepository,
    onDeckSaved: (List<String>) -> Unit,
) {
    val scope = rememberCoroutineScopeCompat()
    var selected by remember { mutableStateOf(linkedSetOf<String>()) }
    var validation by remember { mutableStateOf<DeckValidationResult?>(null) }

    Column(modifier = Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Configure your deck (${selected.size}/8)", style = MaterialTheme.typography.titleLarge)

        when (val v = validation) {
            is DeckValidationResult.Invalid -> Text(v.reasons.joinToString(" • "), color = MaterialTheme.colorScheme.error)
            DeckValidationResult.Valid -> Text("Deck is valid.", color = MaterialTheme.colorScheme.primary)
            null -> Unit
        }

        LazyVerticalGrid(columns = GridCells.Fixed(4), modifier = Modifier.weight(1f)) {
            items(cardDatabase.allCards.sortedBy { it.name }) { card ->
                val isSelected = card.id in selected
                Card(
                    modifier = Modifier.padding(4.dp),
                    colors = androidx.compose.material3.CardDefaults.cardColors(
                        containerColor = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surface,
                    ),
                    onClick = {
                        selected = LinkedHashSet(selected).apply {
                            if (isSelected) remove(card.id) else if (size < 8) add(card.id)
                        }
                        validation = null
                    },
                ) {
                    Column(modifier = Modifier.padding(8.dp)) {
                        Text(card.name, style = MaterialTheme.typography.labelMedium)
                        Text("${card.elixirCost} elixir", style = MaterialTheme.typography.labelSmall)
                    }
                }
            }
        }

        Button(
            onClick = {
                val ids = selected.toList()
                validation = DeckValidator.validate(ids, cardDatabase)
                if (validation is DeckValidationResult.Valid) {
                    scope.launch {
                        deckRepository.saveAndActivate("My Deck", ids)
                        onDeckSaved(ids)
                    }
                }
            },
            enabled = selected.size == 8,
        ) {
            Text("Save deck")
        }
    }
}

/** Tiny indirection so this file doesn't need an extra androidx.lifecycle.viewmodel import just for a coroutine scope. */
@Composable
private fun rememberCoroutineScopeCompat() = androidx.compose.runtime.rememberCoroutineScope()
