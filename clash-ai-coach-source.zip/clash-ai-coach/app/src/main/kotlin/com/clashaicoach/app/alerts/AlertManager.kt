package com.clashaicoach.app.alerts

import android.content.Context
import android.speech.tts.TextToSpeech
import android.util.Log
import java.util.Locale
import java.util.UUID

data class AlertSettings(
    val voiceEnabled: Boolean = true,
    val textEnabled: Boolean = true,
    /** Minimum gap between two spoken alerts of the SAME [AlertKind], to satisfy spec 12's
     *  "avoid excessive repeated announcements". Different kinds are not rate-limited against
     *  each other. */
    val minSecondsBetweenSameKind: Double = 4.0,
    val volume: Float = 1.0f,
    val locale: Locale = Locale.getDefault(),
)

enum class AlertKind { CARD_DEPLOYED, ABILITY_ACTIVATED, ELIXIR_MILESTONE, PHASE_CHANGE, RECOMMENDATION }

data class AlertEvent(
    val kind: AlertKind,
    val text: String,
    /** Whether the underlying detection was confident. Spec 12: "Do not announce uncertain
     *  detections as confirmed facts" — low-confidence events are rendered with hedging language
     *  by the caller (e.g. "Opponent might have played...") rather than suppressed outright,
     *  since the player still benefits from a heads-up. */
    val isConfident: Boolean,
    val timestampSeconds: Double,
)

/**
 * Wraps Android [TextToSpeech] with the two behaviors spec 12 explicitly calls for: per-kind
 * rate limiting, and independent voice/text toggles. The text side is exposed via [onTextAlert]
 * for the UI/overlay to render — this class does not post notifications itself, keeping a single
 * responsibility (speech + gating), with text rendering left to the overlay/UI layer that already
 * owns the screen.
 */
class AlertManager(context: Context) {

    var settings: AlertSettings = AlertSettings()

    var onTextAlert: ((AlertEvent) -> Unit)? = null

    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private val lastSpokenAt = HashMap<AlertKind, Double>()

    init {
        tts = TextToSpeech(context.applicationContext) { status ->
            if (status == TextToSpeech.SUCCESS) {
                ttsReady = true
                tts?.language = settings.locale
            } else {
                Log.e("AlertManager", "TTS init failed with status $status; voice alerts will be silently unavailable")
            }
        }
    }

    fun announce(event: AlertEvent) {
        if (settings.textEnabled) {
            onTextAlert?.invoke(event)
        }
        if (!settings.voiceEnabled || !ttsReady) return

        val last = lastSpokenAt[event.kind]
        if (last != null && event.timestampSeconds - last < settings.minSecondsBetweenSameKind) {
            return // rate-limited: spec 12 "avoid excessive repeated announcements"
        }
        lastSpokenAt[event.kind] = event.timestampSeconds

        val spokenText = if (event.isConfident) event.text else hedgeLanguage(event.text)
        tts?.setSpeechRate(1.0f)
        tts?.speak(spokenText, TextToSpeech.QUEUE_ADD, null, UUID.randomUUID().toString())
    }

    /** Spec 12: never state an uncertain detection as a confirmed fact. */
    private fun hedgeLanguage(text: String): String = "Possibly: $text"

    fun setVolume(volume: Float) {
        settings = settings.copy(volume = volume.coerceIn(0f, 1f))
    }

    fun shutdown() {
        tts?.stop()
        tts?.shutdown()
        tts = null
        ttsReady = false
    }
}
