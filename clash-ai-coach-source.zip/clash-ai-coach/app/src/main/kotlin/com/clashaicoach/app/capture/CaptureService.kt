package com.clashaicoach.app.capture

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.util.DisplayMetrics
import android.util.Log
import androidx.core.app.NotificationCompat
import com.clashaicoach.app.R
import com.clashaicoach.app.pipeline.FramePipeline
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

/**
 * Foreground service that owns the [MediaProjection] session and pulls frames off an
 * [ImageReader]-backed [VirtualDisplay], per spec section 3.
 *
 * Frame handling notes (spec 3: "process frames efficiently", "avoid unnecessary memory
 * allocations", "avoid excessive battery consumption"):
 *  - Frames are captured at [captureWidth]x[captureHeight] (a downscaled virtual display, NOT the
 *    device's native resolution) because card/arena recognition does not need 1440p input and
 *    processing full-resolution frames at the device's native refresh would be wasteful on a
 *    phone. The downscale factor is conservative (see CAPTURE_SCALE) and should be tuned once
 *    real detection-accuracy numbers exist (see docs/LIMITATIONS.md).
 *  - Frame sampling: only every [frameSampleInterval]th available frame is forwarded to the
 *    vision pipeline; Clash Royale deployments and ability animations last well over a second,
 *    so analyzing every single frame of a 30fps+ capture buys little and costs battery/thermals
 *    (spec 16). Dropped frames are closed immediately, not queued, so memory stays bounded.
 *  - ImageReader's Image objects are closed in a `use {}`/finally block on every path to avoid
 *    leaking the (limited) buffer pool, which would otherwise stall capture entirely.
 *
 * Lifecycle notes (spec 3: "Handle Android 14+ MediaProjection restrictions and lifecycle
 * callbacks"):
 *  - [MediaProjection.Callback.onStop] is registered because Android 14+ can stop a projection
 *    session out from under the app (e.g. the system revokes it, or the user stops it from the
 *    system status-bar / share-indicator control) — the service MUST react to that rather than
 *    keep calling into a dead projection (which throws).
 *  - From Android 14 (API 34), `startForeground()` for a `mediaProjection`-typed foreground
 *    service must be called only AFTER MediaProjection.registerCallback and generally the whole
 *    projection token must be (re)obtained via a fresh user consent each time capture restarts —
 *    the token is not safely reusable across a stop/start cycle. This service always expects a
 *    fresh `Intent` carrying a new result code + data from the system permission dialog on every
 *    start, rather than caching the token.
 */
class CaptureService : Service() {

    companion object {
        private const val TAG = "CaptureService"
        const val NOTIFICATION_CHANNEL_ID = "capture_status"
        const val NOTIFICATION_ID = 1001

        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_RESULT_DATA = "result_data"
        const val ACTION_STOP = "com.clashaicoach.app.capture.STOP"

        /** Downscale factor applied to the device's real display metrics for the virtual display. */
        private const val CAPTURE_SCALE = 0.5

        /** Forward every Nth frame to the vision pipeline; the rest are closed unread. */
        private const val DEFAULT_FRAME_SAMPLE_INTERVAL = 3
    }

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    private var mediaProjection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private var imageReaderThread: HandlerThread? = null
    private var imageReaderHandler: Handler? = null

    private var frameCounter = 0
    var frameSampleInterval: Int = DEFAULT_FRAME_SAMPLE_INTERVAL

    /** Null until real card/ability detection models are wired in (see docs/LIMITATIONS.md). */
    var framePipeline: FramePipeline? = null

    private var status: CaptureStatus = CaptureStatus.Idle
        set(value) {
            field = value
            CaptureStatusBus.update(value)
        }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopCapture()
            stopSelf()
            return START_NOT_STICKY
        }

        val resultCode = intent?.getIntExtra(EXTRA_RESULT_CODE, -1) ?: -1
        val resultData: Intent? = if (Build.VERSION.SDK_INT >= 33) {
            intent?.getParcelableExtra(EXTRA_RESULT_DATA, Intent::class.java)
        } else {
            @Suppress("DEPRECATION")
            intent?.getParcelableExtra(EXTRA_RESULT_DATA)
        }

        if (resultCode == -1 || resultData == null) {
            Log.e(TAG, "CaptureService started without a valid MediaProjection grant; stopping.")
            status = CaptureStatus.Error("No screen-capture permission result was supplied")
            stopSelf()
            return START_NOT_STICKY
        }

        ensureNotificationChannel()
        // Must call startForeground() before touching MediaProjection on Android 14+, per the
        // platform's own ordering requirement for a mediaProjection-typed foreground service.
        startForeground(NOTIFICATION_ID, buildNotification("Starting capture…"))

        startCapture(resultCode, resultData)
        return START_STICKY
    }

    private fun startCapture(resultCode: Int, resultData: Intent) {
        val projectionManager = getSystemService(MediaProjectionManager::class.java)
        val projection = projectionManager.getMediaProjection(resultCode, resultData)
        mediaProjection = projection

        projection.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() {
                // Android 14+: the system (or the user, via the share indicator) can end the
                // projection at any time. We must tear down cleanly rather than let subsequent
                // calls into a dead projection throw.
                Log.w(TAG, "MediaProjection stopped externally; tearing down capture.")
                status = CaptureStatus.Stopped("Screen capture was stopped from the system UI")
                stopCapture()
                stopSelf()
            }
        }, null)

        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        windowManagerDisplay()?.getRealMetrics(metrics)
        val width = (metrics.widthPixels * CAPTURE_SCALE).toInt().coerceAtLeast(2)
        val height = (metrics.heightPixels * CAPTURE_SCALE).toInt().coerceAtLeast(2)
        val density = metrics.densityDpi

        imageReaderThread = HandlerThread("CaptureImageReader").apply { start() }
        imageReaderHandler = Handler(imageReaderThread!!.looper)

        val reader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
        imageReader = reader
        reader.setOnImageAvailableListener({ onImageAvailable(it) }, imageReaderHandler)

        virtualDisplay = projection.createVirtualDisplay(
            "ClashAiCoachCapture",
            width, height, density,
            android.hardware.display.DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            reader.surface, null, imageReaderHandler,
        )

        status = CaptureStatus.Capturing(width, height)
        updateNotification("Capturing (${width}x${height})")
    }

    private fun onImageAvailable(reader: ImageReader) {
        val image = try {
            reader.acquireLatestImage()
        } catch (e: IllegalStateException) {
            Log.w(TAG, "acquireLatestImage failed (reader likely closing): ${e.message}")
            null
        } ?: return

        frameCounter++
        val shouldProcess = frameCounter % frameSampleInterval == 0
        if (!shouldProcess) {
            image.close()
            return
        }

        val pipeline = framePipeline
        if (pipeline == null) {
            // No vision pipeline wired up yet — close immediately so we never leak buffers.
            // This is the honest, documented state of the vision system: see
            // core/.../vision and docs/LIMITATIONS.md. Capture itself works; nothing consumes
            // the frames yet beyond this point.
            image.close()
            return
        }

        serviceScope.launch {
            try {
                pipeline.onFrame(image, frameCounter)
            } catch (e: Exception) {
                Log.e(TAG, "Frame pipeline threw on frame $frameCounter", e)
            } finally {
                image.close()
            }
        }
    }

    private fun stopCapture() {
        virtualDisplay?.release()
        virtualDisplay = null
        imageReader?.close()
        imageReader = null
        imageReaderThread?.quitSafely()
        imageReaderThread = null
        mediaProjection?.stop()
        mediaProjection = null
        status = CaptureStatus.Idle
    }

    override fun onDestroy() {
        stopCapture()
        serviceScope.cancel()
        super.onDestroy()
    }

    private fun windowManagerDisplay(): android.view.Display? =
        if (Build.VERSION.SDK_INT >= 30) {
            display
        } else {
            @Suppress("DEPRECATION")
            (getSystemService(WINDOW_SERVICE) as android.view.WindowManager).defaultDisplay
        }

    private fun ensureNotificationChannel() {
        val manager = getSystemService(NotificationManager::class.java)
        val channel = NotificationChannel(
            NOTIFICATION_CHANNEL_ID,
            "Screen capture status",
            NotificationManager.IMPORTANCE_LOW,
        ).apply { description = "Shows when Clash AI Coach is reading the screen" }
        manager.createNotificationChannel(channel)
    }

    private fun buildNotification(text: String): Notification {
        val stopIntent = Intent(this, CaptureService::class.java).apply { action = ACTION_STOP }
        val stopPendingIntent = PendingIntent.getService(
            this, 0, stopIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        return NotificationCompat.Builder(this, NOTIFICATION_CHANNEL_ID)
            .setContentTitle("Clash AI Coach")
            .setContentText(text)
            .setSmallIcon(R.drawable.ic_capture_status)
            .setOngoing(true)
            .addAction(0, "Stop capture", stopPendingIntent)
            .build()
    }

    private fun updateNotification(text: String) {
        val manager = getSystemService(NotificationManager::class.java)
        manager.notify(NOTIFICATION_ID, buildNotification(text))
    }
}

sealed class CaptureStatus {
    data object Idle : CaptureStatus()
    data class Capturing(val width: Int, val height: Int) : CaptureStatus()
    data class Stopped(val reason: String) : CaptureStatus()
    data class Error(val message: String) : CaptureStatus()
}

/**
 * Minimal process-local status broadcaster so the UI (spec 13: "clear indicators for screen
 * capture status") can observe [CaptureStatus] without binding to the service. A real
 * implementation might use a StateFlow exposed from a bound service instead; this is
 * intentionally simple since the UI layer around it is still a functional-foundation skeleton
 * (see docs/LIMITATIONS.md).
 */
object CaptureStatusBus {
    private val listeners = mutableListOf<(CaptureStatus) -> Unit>()
    @Volatile var current: CaptureStatus = CaptureStatus.Idle
        private set

    fun update(status: CaptureStatus) {
        current = status
        listeners.forEach { it(status) }
    }

    fun observe(listener: (CaptureStatus) -> Unit) {
        listeners.add(listener)
        listener(current)
    }

    fun removeObserver(listener: (CaptureStatus) -> Unit) {
        listeners.remove(listener)
    }
}
