# ONNX Runtime and Room both ship their own consumer proguard rules; nothing project-specific
# is required yet since no custom JNI/reflection-based code has been added beyond those libraries.
