# Clash AI Coach

An observation-only, on-device tactical assistant for Clash Royale. It watches your screen via
Android's `MediaProjection` API, tries to recognize what the opponent plays, estimates their
elixir and card cycle, and shows suggestions in a floating overlay. **It never touches input,
memory, or network traffic for the game — it only reads the screen.**

See `docs/LIMITATIONS.md` for an honest, itemized account of what currently works versus what is
a real-but-untrained foundation, and `docs/TEST_REPORT.md` for actual test results (not claimed
ones).

## Why there's no prebuilt APK in this delivery

This project was built in a sandboxed environment with **no Android SDK, no Gradle, no Kotlin/Java
compiler, and no network access** (verified directly: `javac` is absent, `curl` cannot resolve any
host). It is not possible to compile this project or produce an APK from inside that environment.
What IS in this delivery is a complete, real Android Studio project — every file is genuine source,
not a mockup — that will build normally once opened in an environment that has Android Studio.

## Project structure

```
clash-ai-coach/
├── core/                    # Pure Kotlin/JVM module — all game logic, zero Android dependency.
│   └── src/main/kotlin/com/clashaicoach/core/
│       ├── model/           # Card, ability, rarity/category data classes
│       ├── db/              # CardDatabase (loads + merges card/ability JSON)
│       ├── match/           # ElixirTracker, elixir regen phase/clock math
│       ├── cycle/           # CardCycleTracker (opponent card-cycle estimation)
│       ├── ability/         # AbilityDetectionEngine (deploy vs ability vs persistent vs repeat vs reuse)
│       ├── deck/            # PlayerDeck + validation
│       └── coach/           # CoachEngine (rule-based tactical recommendations)
│   └── src/test/kotlin/...  # JUnit 5 tests for everything above
├── app/                     # Android application module
│   └── src/main/kotlin/com/clashaicoach/app/
│       ├── capture/         # CaptureService (MediaProjection foreground service)
│       ├── pipeline/        # FramePipeline + VisionDetector (vision integration point — see LIMITATIONS)
│       ├── overlay/         # OverlayService (floating WindowManager overlay)
│       ├── alerts/          # AlertManager (TTS + text alerts, spec 12)
│       ├── data/            # Room-based deck persistence
│       └── ui/              # MainActivity (permission flow + Home) + DeckConfigScreen
├── data/                    # Source-of-truth JSON: cards.json, abilities.json, counters.json
│   └── (copied into app/src/main/assets by tools/sync_assets.sh)
├── training/                # Dataset plan + runnable-but-not-yet-run training scaffold
├── tools/                   # export_class_list.py, sync_assets.sh
└── docs/                    # LIMITATIONS.md, TEST_REPORT.md
```

## Building (once you have Android Studio)

1. Open the `clash-ai-coach/` directory in Android Studio (Ladybug or newer recommended).
2. Let Android Studio generate `gradle/wrapper/gradle-wrapper.jar` (the properties file pinning
   Gradle 8.9 is already in place; the jar binary itself could not be downloaded in this sandbox —
   Android Studio does this automatically on first sync, or run `gradle wrapper` once if you have
   a system Gradle install).
3. Sync Gradle. It will fetch AGP 8.7.2, Kotlin 2.0.21, and the dependencies listed in each
   module's `build.gradle.kts` from Google's and Maven Central's repositories.
4. Run `:core:test` to execute the JUnit test suite (no device/emulator needed — pure JVM module).
5. Run the `app` configuration on a device running Android 10 (API 29) or newer. The target device
   is a Redmi Note 15 Pro+ 5G (Android 16 / HyperOS 3); the app should also run on other modern
   Android 10+ devices.

## Installing and granting permissions (on a built APK)

1. Install the debug APK (`adb install app-debug.apk`, or sideload it).
2. Open the app. On Android 13+, grant the notification permission when prompted (required for
   the capture/overlay foreground-service status notifications to show).
3. Tap "Grant 'draw over other apps' permission" — this opens a system Settings screen (there is
   no in-app dialog for this permission category); toggle the switch and return to the app.
4. Configure your 8-card deck (manual selection; works fully offline).
5. Tap "Start screen capture" — Android's screen-capture consent dialog appears; accepting it
   starts the capture foreground service, which shows a persistent "Capturing" notification with
   a Stop action.
6. Tap "Show floating overlay" to display the live info panel over the game.

**Important honesty note:** at this stage, capture and the overlay UI both work, but the overlay
will show default placeholder values (no cards detected) because no trained vision model exists
yet. See `docs/LIMITATIONS.md`.

## Updating the card/ability database

Edit `data/cards.json` / `data/abilities.json` / `data/counters.json`, then run
`tools/sync_assets.sh` to copy the updated files into `app/src/main/assets/` before rebuilding.
`CardDatabase.applyUpdate()` also supports merging a newer JSON payload at runtime, for a future
in-app "check for card updates" feature (not implemented).
