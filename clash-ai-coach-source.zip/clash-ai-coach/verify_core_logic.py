"""
Logic-equivalence verification for core/ElixirTracker.kt and CardCycleTracker.kt.

This sandbox has no Kotlin compiler, no javac, and no network access to fetch
one (verified: `javac` absent, `curl` cannot resolve any host). This script
re-implements the SAME algorithms in Python so the numeric behavior can
actually be executed and checked against known Clash Royale rules, rather
than asserted without having run anything. It is not a substitute for
compiling and running the real Kotlin unit tests in Android Studio / CI
(see app/src/test and core/src/test) — it verifies the algorithm, not the
Kotlin source file itself compiles.
"""

import math

SINGLE, DOUBLE, TRIPLE = 1, 2, 3
BASE_INTERVAL = 2.8


def phase(reg_elapsed, is_ot, ot_elapsed):
    if is_ot and ot_elapsed >= 60.0:
        return TRIPLE
    if is_ot:
        return DOUBLE
    if reg_elapsed >= 120.0:
        return DOUBLE
    return SINGLE


def seconds_until_boundary(reg_elapsed, is_ot, ot_elapsed):
    if is_ot and ot_elapsed < 60.0:
        return 60.0 - ot_elapsed
    if is_ot:
        return None
    if reg_elapsed < 120.0:
        return 120.0 - reg_elapsed
    return None


class ElixirTracker:
    def __init__(self, initial=5.0, base_interval=BASE_INTERVAL):
        self.elixir = min(10.0, max(0.0, initial))
        self.reg_elapsed = 0.0
        self.is_ot = False
        self.ot_elapsed = 0.0
        self.base_interval = base_interval
        self.applied_keys = set()
        self.events = []

    def enter_overtime(self):
        self.is_ot = True
        self.ot_elapsed = 0.0

    def advance_time(self, delta):
        assert delta >= 0
        remaining = delta
        while remaining > 0:
            boundary = seconds_until_boundary(self.reg_elapsed, self.is_ot, self.ot_elapsed)
            step = min(boundary, remaining) if boundary is not None else remaining
            if step > 0:
                rate = phase(self.reg_elapsed, self.is_ot, self.ot_elapsed) / self.base_interval
                before = self.elixir
                self.elixir = min(10.0, self.elixir + step * rate)
                self.events.append(("regen", self.elixir - before))
            if self.is_ot:
                self.ot_elapsed = min(120.0, self.ot_elapsed + step)
            else:
                self.reg_elapsed = min(180.0, self.reg_elapsed + step)
            remaining -= step
            if step <= 0:
                break

    def apply_deployment(self, cost, event_key, confidence=1.0, reject_below=0.2):
        if event_key in self.applied_keys:
            self.events.append(("rejected_dup", 0))
            return False
        if confidence < reject_below:
            self.events.append(("rejected_low_conf", 0))
            return False
        self.applied_keys.add(event_key)
        before = self.elixir
        self.elixir = max(0.0, self.elixir - cost)
        self.events.append(("deploy", self.elixir - before))
        return True


def test_regen_single_phase_rate():
    t = ElixirTracker(initial=0.0)
    t.advance_time(2.8)
    assert abs(t.elixir - 1.0) < 1e-9, t.elixir
    print("PASS: single-phase regen: 2.8s -> +1.0 elixir, got", t.elixir)


def test_regen_crosses_into_double_phase():
    # Deliberately start comfortably below the 10-elixir cap (5.0) so the boundary-crossing
    # integration itself is being tested, not obscured by saturation. Elapsed time is set
    # directly (rather than accumulated via advance_time from 0) for the same reason: from 0,
    # single-phase regen alone saturates the 10-cap in 28s, long before reaching 119s.
    t = ElixirTracker(initial=5.0)
    t.reg_elapsed = 119.0
    before = t.elixir
    t.advance_time(3.0)  # crosses 120s boundary mid-interval
    # Expected: 1s remaining at rate 1/2.8, then 2s at rate 2/2.8
    expected_gain = 1.0 * (1 / 2.8) + 2.0 * (2 / 2.8)
    assert abs((t.elixir - before) - expected_gain) < 1e-9, (t.elixir - before, expected_gain)
    print("PASS: regen correctly integrates across the single->double phase boundary:",
          round(t.elixir - before, 4), "== expected", round(expected_gain, 4))


def test_double_to_triple_via_overtime():
    t = ElixirTracker(initial=0.5)  # kept well under the 10-cap; see note above (gain here is ~8.93)
    t.is_ot = True
    t.ot_elapsed = 55.0
    assert phase(t.reg_elapsed, t.is_ot, t.ot_elapsed) == DOUBLE
    before = t.elixir
    t.advance_time(10.0)  # crosses the 60s-of-OT boundary into triple
    expected_gain = 5.0 * (2 / 2.8) + 5.0 * (3 / 2.8)
    assert abs((t.elixir - before) - expected_gain) < 1e-9, (t.elixir - before, expected_gain)
    print("PASS: overtime double->triple boundary handled correctly")


def test_never_exceeds_10_or_goes_negative():
    t = ElixirTracker(initial=9.5)
    t.advance_time(50.0)  # would overshoot past 10 without clamping
    assert t.elixir == 10.0, t.elixir
    t2 = ElixirTracker(initial=1.0)
    t2.apply_deployment(5, "k1")  # would go negative without clamping
    assert t2.elixir == 0.0, t2.elixir
    print("PASS: elixir clamps to [0, 10]")


def test_duplicate_event_key_rejected():
    t = ElixirTracker(initial=10.0)
    applied1 = t.apply_deployment(4, "deploy-hogrider-142.3-track7")
    applied2 = t.apply_deployment(4, "deploy-hogrider-142.3-track7")  # same event, later frame
    assert applied1 is True and applied2 is False
    assert t.elixir == 6.0, t.elixir  # only deducted once
    print("PASS: duplicate event key is rejected, no double-deduction")


def test_low_confidence_rejected_outright():
    t = ElixirTracker(initial=10.0)
    applied = t.apply_deployment(4, "k1", confidence=0.05, reject_below=0.2)
    assert applied is False
    assert t.elixir == 10.0
    print("PASS: very low confidence detection does not cause a deduction")


class CardCycleTracker:
    def __init__(self):
        self.history = []  # list of (card_id, play_index)
        self.seen = []
        self.counter = 0

    def record_play(self, card_id):
        self.counter += 1
        self.history.append((card_id, self.counter))
        if card_id not in self.seen:
            self.seen.append(card_id)

    def known_deck_size(self):
        return 8 if len(self.seen) >= 8 else None

    def estimates(self):
        last_index = {}
        for card_id, idx in self.history:
            last_index[card_id] = idx
        out = {}
        for card_id in self.seen:
            idx = last_index[card_id]
            distinct_since = len(set(c for c, i in self.history if i > idx))
            out[card_id] = distinct_since
        return out


def test_cycle_unknown_deck_reports_no_certainty():
    c = CardCycleTracker()
    for card in ["hog_rider", "ice_golem", "cannon"]:
        c.record_play(card)
    assert c.known_deck_size() is None
    print("PASS: cycle tracker refuses to call the deck complete with only 3 distinct cards seen")


def test_cycle_full_lap_detection():
    c = CardCycleTracker()
    deck = ["hog_rider", "ice_golem", "cannon", "musketeer", "fireball", "skeletons", "the_log", "zap"]
    for card in deck:
        c.record_play(card)
    assert c.known_deck_size() == 8
    # Play 7 more distinct-from-hog_rider cards (cycling through the other 7) -> hog_rider should show playsSinceLastSeen == 7
    for card in deck[1:]:
        c.record_play(card)
    est = c.estimates()
    assert est["hog_rider"] == 7, est["hog_rider"]
    print("PASS: full 7-card lap correctly detected for hog_rider ->", est["hog_rider"])


def test_regen_boundary_via_saturate_then_drain_matches_junit_test():
    # Exactly mirrors the corrected Kotlin JUnit test in ElixirTrackerTest.kt, to make sure
    # that exact sequence (saturate at cap, drain via a deployment, cross the boundary) is
    # numerically sound before trusting the Kotlin file to behave the same way.
    t = ElixirTracker(initial=0.0)
    t.advance_time(28.0)
    assert t.elixir == 10.0
    t.advance_time(91.0)
    assert t.elixir == 10.0
    assert t.reg_elapsed == 119.0
    t.apply_deployment(8, "drain")
    before = t.elixir
    assert before == 2.0
    t.advance_time(3.0)
    expected_gain = 1.0 * (1 / 2.8) + 2.0 * (2 / 2.8)
    assert abs((t.elixir - before) - expected_gain) < 1e-9
    print("PASS: saturate->drain->cross-boundary sequence (matches the Kotlin JUnit test) is numerically correct")


if __name__ == "__main__":
    tests = [v for k, v in sorted(globals().items()) if k.startswith("test_")]
    failures = 0
    for t in tests:
        try:
            t()
        except AssertionError as e:
            failures += 1
            print(f"FAIL: {t.__name__}: {e}")
    print(f"\n{len(tests) - failures}/{len(tests)} logic-equivalence checks passed")
    if failures:
        raise SystemExit(1)
